<?php
namespace App\Http\Controllers;

use App\Models\User;
use App\Models\UserMaster;
use App\Models\CommonVendorMaster;
use App\Models\AuroPartnerMaster;
use App\Models\PartnerUserMapping;
use Illuminate\Http\Request;
use Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Response;
use Redirect;

require (__DIR__.'/../../helper.php');

class CommunicationVendor extends Controller{

    /**
     * Create a new controller instance.
     * Kohin Maji     * @return void
     */
    public function __construct(){
        //$this->middleware('auth');
    }

   
    
    
    public function index(Request $request){
        //$api_result = ApiMaster::get(array('api_id', 'api_name', 'api_url', 'status', 'created_at'))->toArray();
        
        
        $set_limit=10;
        $set_page=1;

        $filePath =  array("set_limit" => $set_limit, "set_page" => $set_page);
        $curl = curl_init();
        curl_setopt_array($curl, array(
        CURLOPT_URL => "localhost/Techno_Brains/auroscholar/apis/partner/comm_vendor_list.php",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30000,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => json_encode($filePath),
        CURLOPT_HTTPHEADER => array(
        // Set here requred headers
        "content-type: application/json",
        "Secret-Id: 2198f0011288666d3694ccf4e7d16c29",
        "Secret-Key: f7115915ae4efc1bdab7ae9fc686348848f8cc2e7bf4a9",
        "Lang-Code: english"
        ),
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if($err){
            echo "cURL Error #:" . $err;
        }
        else{
            $result = json_decode($response, true);
            // $api_result=$result['data'];
            // print_r($result); 
            return view('CommunicationVendor.list', ['result'=>$result]);        
        }   
        
        
        // return view('partner.partnerlist',compact('api_result'));
    }
    
    public function add(){
        return view('CommunicationVendor.add');
    }

     public function save(Request $request){
        $post_data = $request->toArray();

        //$login_user_id = auth()->user()['id'];

        if(!empty($check_exist_result->partner_id)){ // redirect if already exist
            return redirect()->route('partner.addpartner')
             ->with('error','Partner Combination already exist');
        }
        $request->validate([
            'vendor_contact_email' => 'required|email'
        ]);
        $auro_partner_master = [];
        $auro_partner_master['vendor_name'] = $post_data['vendor_name'];
        $auro_partner_master['service_name'] = $post_data['service_name'];
        $auro_partner_master['vendor_contact_name'] =  $post_data['vendor_contact_name'];
        $auro_partner_master['vendor_contact_no'] = $post_data['vendor_contact_no'];
        $auro_partner_master['vendor_contact_email'] = $post_data['vendor_contact_email'];
        $auro_partner_master['vendor_remark'] = $post_data['vendor_remark'];
        $auro_partner_master['status'] = 1;
        $auro_partner_master['created_at'] = date('Y-m-d H:i:s');
        $auro_partner_master['updated_at'] = date('Y-m-d H:i:s');

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "localhost/Techno_Brains/auroscholar/apis/partner/comm_vendor_insert.php",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode($auro_partner_master),
            CURLOPT_HTTPHEADER => array(
        // Set here requred headers
        "content-type: application/json",
        "Secret-Id: 2198f0011288666d3694ccf4e7d16c29",
        "Secret-Key: f7115915ae4efc1bdab7ae9fc686348848f8cc2e7bf4a9",
        "Lang-Code: english"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        } 
        else {
            // print_r(json_decode($response));die;
            $resp = json_decode($response);
            if($resp->response_code===200){
                return redirect()->route('comm_vendor.list')->with('message', $resp->message);
            }
            // else{
            //     return redirect()->route('comm_vendor.add')->with('message', $resp->message);
            // }
        }

        // AuroPartnerMaster::create($auro_partner_master);

        // return redirect()->route('partner.partnerlist')->with('message','Partner added succesfully');
    }

    public function edit($id){
        
        $filePath =  array("com_vendor_id" => $id);
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "localhost/Techno_Brains/auroscholar/apis/partner/comm_vendor_view.php",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode($filePath),
            CURLOPT_HTTPHEADER => array(
        // Set here requred headers
        "content-type: application/json",
        "Secret-Id: 2198f0011288666d3694ccf4e7d16c29",
        "Secret-Key: f7115915ae4efc1bdab7ae9fc686348848f8cc2e7bf4a9",
        "Lang-Code: english"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        } 
        else {
            // print_r(json_decode($response));
            $resp = json_decode($response);
            if($resp->response_code===200){
                $partner_data = $resp->data;
                return view('CommunicationVendor.edit',compact('partner_data'));
                // return redirect()->route('partner.partnerlist')->with('message', $resp->message);
            }
            else{
                return redirect()->route('comm_vendor.list')->with('message', $resp->message);
            }
        }  
    }

    public function update(Request $request){
        $post_data = $request->toArray();
        // return $post_data;
        //$login_user_id = auth()->user()['id'];

        if(!empty($check_exist_result->com_vendor_id)){ // redirect if already exist
            return redirect()->route('comm_vendor.edit',$post_data['com_vendor_id'])->with('error','Partner Combination already exist');
        }

        // $request->validate([
        //     'partner_name' => 'required',
        //     'partner_source' => 'required'
        // ]);
        
        $auro_partner_master = [];
        $auro_partner_master['com_vendor_id'] = $post_data['com_vendor_id'];
        $auro_partner_master['vendor_name'] = $post_data['vendor_name'];
        $auro_partner_master['service_name'] = $post_data['service_name'];
        $auro_partner_master['vendor_contact_name'] =  $post_data['vendor_contact_name'];
        $auro_partner_master['vendor_contact_no'] = $post_data['vendor_contact_no'];
        $auro_partner_master['vendor_contact_email'] = $post_data['vendor_contact_email'];
        $auro_partner_master['vendor_remark'] = $post_data['vendor_remark'];
        $auro_partner_master['status'] = 1;
        $auro_partner_master['updated_by'] = 1;

        // return $auro_partner_master['required_params'];die;

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "localhost/Techno_Brains/auroscholar/apis/partner/comm_vendor_update.php",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode($auro_partner_master),
            CURLOPT_HTTPHEADER => array(
        // Set here requred headers
        "content-type: application/json",
        "Secret-Id: 2198f0011288666d3694ccf4e7d16c29",
        "Secret-Key: f7115915ae4efc1bdab7ae9fc686348848f8cc2e7bf4a9",
        "Lang-Code: english"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        } 
        else {
            // print_r(json_decode($response));die;
            $resp = json_decode($response);
            if($resp->response_code===200){
                return redirect()->route('comm_vendor.list')->with('message', $resp->message);
            }
            else{
                return redirect()->route('comm_vendor.edit')->with('message', $resp->message);
            }
        }
        // ApiKeyMaster::where('user_id',$post_data['user_id'])->update($auro_partner_master);
        // return redirect()->route('partner.partnerlist')->with('message','Partner updated succesfully');
    }

    public function delete($id){
        
        $filePath =  array("com_vendor_id" => $id);
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "localhost/Techno_Brains/auroscholar/apis/partner/comm_vendor_delete.php",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode($filePath),
            CURLOPT_HTTPHEADER => array(
        // Set here requred headers
        "content-type: application/json",
        "Secret-Id: 2198f0011288666d3694ccf4e7d16c29",
        "Secret-Key: f7115915ae4efc1bdab7ae9fc686348848f8cc2e7bf4a9",
        "Lang-Code: english"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        } 
        else {
            // print_r(json_decode($response));
            $resp = json_decode($response);
                return redirect()->route('comm_vendor.list')->with('message', $resp->message);
                // return redirect()->route('partner.partnerlist')->with('message', $resp->message);
            
        }
            
    }

   
}