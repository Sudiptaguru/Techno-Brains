@extends('layouts.advanced_form')
@section('content')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src='select2/dist/js/select2.min.js' type='text/javascript'></script>
<script>
        $(document).ready(function(){
            
            // Initialize select2
            $("#selUser").select2();

            // Read selected option
            $('#but_read').click(function(){
                var username = $('#selUser option:selected').text();
                var userid = $('#selUser').val();
           
                $('#result').html("i : " + userid + ", name : " + username);
            });
        });
        </script>
        <script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
<section class="content">   
    <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-12 col-md-6 col-sm-7">
                    <ul class="breadcrumb">                        
                        <li class="breadcrumb-item"><a href="">Dashboard</a></li>
                        <li class="breadcrumb-item active">Communication Template List</li>
                    </ul>
                </div>
            </div>
        </div>
        @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
        @endif
        @if (session('message'))
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <span class="text-center">{{ session('message') }}</span>
              </div>
            </div>
          </div>
        @endif

        @if (session('error'))
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <span class="text-center">{{ session('error') }}</span>
              </div>
            </div>
          </div>
        @endif
        <label><b>Partner Name</b></label>
        <select name="partner_name" id="partner_name" id="partner-dd" class="form-control col-md-6">
            <option value="">--Select--</option>
            <option value="8">Ram</option>
            <option value="9">Raban</option>
        </select>

        <input type="hidden" name="partner" id="partner" />
            <div style="clear:both"></div>
                        <div class="add-button text-right">
                            <a href="{{ route('comm_tmpl.add') }}"><button type="button" class="btn btn-raised btn-primary waves-effect">Add Communication Template</button></a>
                        </div>    
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                <thead>
                                    <tr>
                                        <th>Partner Name</th>
                                        <th>Template Name</th>
                                        <th>Communication Type</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                
                                <tbody id="myTable">
                                    @foreach($result['data'] as $comm_tmpl)
                                    <tr>
                                        <td><?php if($comm_tmpl['partner_id']==8){echo "Ram";} else if($comm_tmpl['partner_id']==9){ echo "Raban";} ?></td>
                                        <td>{{ $comm_tmpl['template_name'] }}</td>
                                        <td>{{ $comm_tmpl['com_type'] }}</td>
                                        <td><a class="demo-google-material-icon" href="{{ url('comm_tmpl_edit').'/'.$comm_tmpl['com_template_id'] }}"><i class="material-icons" title="Edit">edit</i></a>|<a class="demo-google-material-icon" href="{{ url('comm_tmpl_delete').'/'.$comm_tmpl['com_template_id'] }}" onclick="return confirm('Are you sure you want to delete this item ?');"><i class="material-icons" title="Delete">delete</i></a></td>
                                    </tr>
                                   @endforeach 
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<link href="css/bootstrap-select.min.css" rel="stylesheet" />
<script src="js/bootstrap-select.min.js"></script>
<script>
$(document).ready(function(){

    load_data();
    
    function load_data(query='')
    {
        $.ajax({
            url:"localhost/test1/ajax-live-data-search-using-multi-select-dropdown-in-php/fetch.php",
            method:"POST",
            data:{query:query},
            success:function(data)
            {
                $('tbody').html(data);
            }
        })
    }

    $('#partner_name').change(function(){
        $('#partner').val($('#partner_name').val());
        var query = $('#partner').val();
        load_data(query);
    });
    
});
</script>
@endsection