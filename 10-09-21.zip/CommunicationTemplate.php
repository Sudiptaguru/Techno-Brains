<?php
namespace App\Http\Controllers;

use App\Models\User;
use App\Models\UserMaster;
use App\Models\AuroPartnerMaster;
use App\Models\PartnerUserMapping;
use Illuminate\Http\Request;
use Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

require (__DIR__.'/../../helper.php');

class CommunicationTemplate extends Controller{

    /**
     * Create a new controller instance.
     * Kohin Maji     * @return void
     */
    public function __construct(){
        //$this->middleware('auth');
    }
    
    public function index(Request $request){
        //$api_result = ApiMaster::get(array('api_id', 'api_name', 'api_url', 'status', 'created_at'))->toArray();
        
        
        $set_limit=10;
        $set_page=1;

        // $filePath =  array("set_limit" => $set_limit, "set_page" => $set_page, "partner_id" => 9);
        $filePath =  array("set_limit" => $set_limit, "set_page" => $set_page);
        $curl = curl_init();
        curl_setopt_array($curl, array(
        CURLOPT_URL => "localhost/Techno_Brains/auroscholar/apis/partner/comm_tmpl_list.php",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30000,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => json_encode($filePath),
        CURLOPT_HTTPHEADER => array(
        // Set here requred headers
        "content-type: application/json",
        "Secret-Id: 2198f0011288666d3694ccf4e7d16c29",
        "Secret-Key: f7115915ae4efc1bdab7ae9fc686348848f8cc2e7bf4a9",
        "Lang-Code: english"
        ),
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if($err){
            echo "cURL Error #:" . $err;
        }
        else{
            $result = json_decode($response, true);
            // $api_result=$result['data'];
            // print_r($result); 
            return view('CommunicationTemplate.list', ['result'=>$result]);        
        }   
        
        
        // return view('partner.partnerlist',compact('api_result'));
    }
    
    public function add(){
        return view('CommunicationTemplate.add');
    }

     public function save(Request $request){
        $post_data = $request->toArray();

        //$login_user_id = auth()->user()['id'];

        // if(!empty($check_exist_result->partner_id)){ // redirect if already exist
        //     return redirect()->route('comm_tmpl.list')
        //      ->with('error','Partner Combination already exist');
        // }
        // $request->validate([
        // 
           // 'partner_name' => 'required',
        //     'partner_source' => 'required'
        // ]);
        $auro_partner_master = [];
        $auro_partner_master['partner_id'] = $post_data['partner_id'];
        $auro_partner_master['template_name'] = $post_data['template_name'];
        $auro_partner_master['com_type'] = $post_data['com_type'];
        $auro_partner_master['template_text'] = $post_data['template_text'];
        $auro_partner_master['status'] = 1;
        $auro_partner_master['created_by'] = 1;
        $auro_partner_master['updated_by'] = 1;

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "localhost/Techno_Brains/auroscholar/apis/partner/comm_tmpl_insert.php",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode($auro_partner_master),
            CURLOPT_HTTPHEADER => array(
        // Set here requred headers
        "content-type: application/json",
        "Secret-Id: 2198f0011288666d3694ccf4e7d16c29",
        "Secret-Key: f7115915ae4efc1bdab7ae9fc686348848f8cc2e7bf4a9",
        "Lang-Code: english"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        } 
        else {
            // print_r(json_decode($response));
            $resp = json_decode($response);
            if($resp->response_code===200){
                return redirect()->route('comm_tmpl.list')->with('message', $resp->message);
            }
            else{
                return redirect()->route('comm_tmpl.add')->with('message', $resp->message);
            }
        }

        // AuroPartnerMaster::create($auro_partner_master);

        // return redirect()->route('partner.partnerlist')->with('message','Partner added succesfully');
    }

    public function edit($id){
        
        $filePath =  array("com_template_id" => $id);
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "localhost/Techno_Brains/auroscholar/apis/partner/comm_tmpl_view.php",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode($filePath),
            CURLOPT_HTTPHEADER => array(
        // Set here requred headers
        "content-type: application/json",
        "Secret-Id: 2198f0011288666d3694ccf4e7d16c29",
        "Secret-Key: f7115915ae4efc1bdab7ae9fc686348848f8cc2e7bf4a9",
        "Lang-Code: english"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        } 
        else {
            // print_r(json_decode($response));
            $resp = json_decode($response);
            if($resp->response_code===200){
                $partner_data = $resp->data;
                return view('CommunicationTemplate.edit',compact('partner_data'));
                // return redirect()->route('partner.partnerlist')->with('message', $resp->message);
            }
            else{
                return redirect()->route('comm_tmpl.edit')->with('message', $resp->message);
            }
        }  
    }

    public function update(Request $request){
        $post_data = $request->toArray();
        // return $post_data;
        //$login_user_id = auth()->user()['id'];

        // if(!empty($check_exist_result->partner_id)){ // redirect if already exist
        //     return redirect()->route('partner.editpartner',$post_data['partner_id'])->with('error','Partner Combination already exist');
        // }

        // $request->validate([
        //     'partner_name' => 'required',
        //     'partner_source' => 'required'
        // ]);
        
        $auro_partner_master = [];
        $auro_partner_master['partner_id'] = 9;
        $auro_partner_master['com_template_id'] = $post_data['com_template_id'];
        $auro_partner_master['template_name'] = $post_data['template_name'];
        $auro_partner_master['com_type'] = $post_data['com_type'];
        $auro_partner_master['template_text'] = $post_data['template_text'];
        $auro_partner_master['status'] = 1;
        $auro_partner_master['created_by'] = 9;
        $auro_partner_master['updated_by'] = 9;

        // return $auro_partner_master['required_params'];die;

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "localhost/Techno_Brains/auroscholar/apis/partner/comm_tmpl_update.php",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode($auro_partner_master),
            CURLOPT_HTTPHEADER => array(
        // Set here requred headers
        "content-type: application/json",
        "Secret-Id: 2198f0011288666d3694ccf4e7d16c29",
        "Secret-Key: f7115915ae4efc1bdab7ae9fc686348848f8cc2e7bf4a9",
        "Lang-Code: english"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        } 
        else {
            // print_r(json_decode($response));die;
            $resp = json_decode($response);
            if($resp->response_code===200){
                return redirect()->route('comm_tmpl.list')->with('message', $resp->message);
            }
            else{
                return redirect()->route('comm_tmpl.edit')->with('message', $resp->message);
            }
        }
        // ApiKeyMaster::where('user_id',$post_data['user_id'])->update($auro_partner_master);
        // return redirect()->route('partner.partnerlist')->with('message','Partner updated succesfully');
    }


    public function delete($id){
        
        $filePath =  array("com_template_id" => $id);
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "localhost/Techno_Brains/auroscholar/apis/partner/comm_tmpl_delete.php",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode($filePath),
            CURLOPT_HTTPHEADER => array(
        // Set here requred headers
        "content-type: application/json",
        "Secret-Id: 2198f0011288666d3694ccf4e7d16c29",
        "Secret-Key: f7115915ae4efc1bdab7ae9fc686348848f8cc2e7bf4a9",
        "Lang-Code: english"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        } 
        else {
            // print_r(json_decode($response));
            $resp = json_decode($response);
                return redirect()->route('comm_tmpl.list')->with('message', $resp->message);
                // return redirect()->route('partner.partnerlist')->with('message', $resp->message);
            
        }
            
    }

   
}