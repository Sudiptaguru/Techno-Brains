@extends('layouts.advanced_form')
@section('content')
<section class="content">
    <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-12 col-md-6 col-sm-7">
                    <ul class="breadcrumb">                        
                        <li class="breadcrumb-item"><a href="">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="">Communication Vendor</a></li>
                        <li class="breadcrumb-item active">Add Communication Vendor</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="row clearfix">
            <div class="col-sm-12">
              <div class="">
                @error('vendor_contact_email')
                    <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                @enderror
              </div>
            </div>
          </div>
                                                      
       
        
        <div class="row clearfix">
            <div class="col-lg-12">
                <div class="card">
                    <div class="header">
                        <h2>Add Communication Vendor</h2>
                    </div>
                    <div class="body">
                        <form id="form_validation" action="{{ route('comm_vendor.save') }}" method="POST">
                            @csrf
                            <div class="form-group">
                                <p class="m-t-10"> <b>Vendor Name</b> </p>
                                    <input type="text" class="form-control" name="vendor_name" required>
                            </div>
							
                             <div class="form-group">
                                <p class="m-t-10"> <b>Service Name</b> </p>
                                    <input type="text" class="form-control" name="service_name" required>
                            </div>  

                            <div class="form-group">
                                <p class="m-t-10"> <b>Vendor Contact Name</b> </p>
                                    <input type="text" class="form-control" name="vendor_contact_name">
                            </div>

                            <div class="form-group">
                                <p class="m-t-10"> <b>Vendor Contact No</b> </p>
                                    <input type="text" class="form-control" name="vendor_contact_no">
                            </div>
                            
 							
                            <div class="form-group">
                                <p class="m-t-10"> <b>Vendor Contact Email</b> </p>
                                    <input type="text" class="form-control" name="vendor_contact_email">
                            </div>

                            <div class="form-group">
                                <p class="m-t-10"> <b>Vendor Remark</b> </p>
                                    <input type="text" class="form-control" name="vendor_remark">
                            </div>

							<button class="btn btn-raised btn-primary waves-effect" type="submit">Save</button>
                            <a href="{{ route('comm_vendor.list') }}"><button class="btn btn-raised btn-primary waves-effect" type="button">Cancel</button></a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> 
@endsection