<?php
//use Illuminate\Routing\Route;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\ApiKeyController;
use App\Http\Controllers\CustomSqlController;
use App\Http\Controllers\PartnerController;
use App\Http\Controllers\PartnerUserController;
use App\Http\Controllers\CommunicationTemplate;
use App\Http\Controllers\CommunicationVendor;

use App\Http\Controllers\DonorController;
use App\Http\Controllers\RazorpayController;

use App\Http\Controllers\SearchController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



/* API KEY Master */ 

Route::get('apikey', [ApiKeyController::class, 'index'])->name('apikey.list');

Route::get('add_apikey', [ApiKeyController::class, 'add'])->name('apikey.add');

Route::get('edit_apikey/{id}', [ApiKeyController::class, 'edit'])->name('apikey.edit');

Route::post('save_apikey', [ApiKeyController::class, 'save'])->name('apikey.save');

Route::post('update_apikey', [ApiKeyController::class, 'update'])->name('apikey.update');


Route::get('api', [ApiKeyController::class, 'apilist'])->name('apikey.apilist');

Route::get('add_api', [ApiKeyController::class, 'addapi'])->name('apikey.addapi');

Route::get('edit_api/{id}', [ApiKeyController::class, 'editapi'])->name('apikey.editapi');

Route::post('save_api', [ApiKeyController::class, 'saveapi'])->name('apikey.saveapi');

Route::post('update_api', [ApiKeyController::class, 'updateapi'])->name('apikey.updateapi');

Route::get('delete_api/{id}', [ApiKeyController::class, 'deleteapi'])->name('apikey.deleteapi');

/* End API KEY Master */

/* Custom SQl Master */

Route::get('customsql', [CustomSqlController::class, 'index'])->name('customsql.sql');
Route::post('customsql', [CustomSqlController::class, 'save']);

/* End Custom SQl Master */

/* Partner Master */

Route::get('partner', [PartnerController::class, 'partnerlist'])->name('partner.partnerlist');

Route::get('add_partner', [PartnerController::class, 'addpartner'])->name('partner.addpartner');

Route::post('savepartner', [PartnerController::class, 'savepartner'])->name('partner.savepartner');

Route::get('edit_partner/{id}', [PartnerController::class, 'editpartner'])->name('partner.editpartner');

Route::post('update_partner', [PartnerController::class, 'updatepartner'])->name('partner.updatepartner');

Route::get('delete_partner/{id}', [PartnerController::class, 'deletepartner'])->name('partner.deletepartner');

/* End Partner Master */

/* Partner User Master */

Route::get('partneruser/{id}', [PartnerUserController::class, 'index'])->name('partneruser.list');

Route::get('add_partneruser/{id}', [PartnerUserController::class, 'add'])->name('partneruser.add');

Route::post('savepartneruser', [PartnerUserController::class, 'save'])->name('partneruser.save');

Route::get('edit_partneruser/{id}', [PartnerUserController::class, 'edit'])->name('partneruser.edit');

Route::post('update_partneruser', [PartnerUserController::class, 'update'])->name('partneruser.update');

Route::get('delete_partneruser/{id}', [PartnerUserController::class, 'delete']);

/* End Partner User Master */

/*Communication Template*/ 

Route::get('comm_tmpl', [CommunicationTemplate::class, 'index'])->name('comm_tmpl.list');

Route::get('comm_tmpl_add', [CommunicationTemplate::class, 'add'])->name('comm_tmpl.add');

Route::post('comm_tmpl_save', [CommunicationTemplate::class, 'save'])->name('comm_tmpl.save');

Route::get('comm_tmpl_edit/{id}', [CommunicationTemplate::class, 'edit'])->name('comm_tmpl.edit');

Route::post('comm_tmpl_update', [CommunicationTemplate::class, 'update'])->name('comm_tmpl.update');

Route::get('comm_tmpl_delete/{id}', [CommunicationTemplate::class, 'delete']);

/* End Communication Template */

/*Communication Vendor*/ 

Route::get('communication_vendor', [CommunicationVendor::class, 'index'])->name('comm_vendor.list');

Route::get('add_comm_vendor', [CommunicationVendor::class, 'add'])->name('comm_vendor.add');

Route::post('save', [CommunicationVendor::class, 'save'])->name('comm_vendor.save');

Route::get('edit_comm_vendor/{id}', [CommunicationVendor::class, 'edit'])->name('comm_vendor.edit');

Route::post('update_comm_vendor', [CommunicationVendor::class, 'update'])->name('comm_vendor.update');

Route::get('delete_comm_vendor/{id}', [CommunicationVendor::class, 'delete']);

/* End Communication Vendor */

Route::get('search', [SearchController::class, 'index']);

/* 
|--------------------------------------------------------------------------
| Admin View Routes
|-------------------------------------------------------------------------- 
*/
// dashboard page route
Route::get('/dashboard', function(){
    return view('admin.dashboard');
})->name('admin.dashboard');



Route::get('/', function () {
    return view('welcome');
});

Route::get('/donor/home', [DonorController::class, 'home']);
Route::post('/donor/home', [DonorController::class, 'adddata']);
//Route::get('/donor/forgotpass', [DonorController::class, 'forgotpass']);
//Route::post('/donor/forgotpass', [DonorController::class, 'forgotpassaction']);
//Route::post('/donor/resetpass', [DonorController::class, 'resetpass']);

Route::post('/donor/login', [DonorController::class, 'login'])->name('donor.login');

Route::get('/donor/dashboard', [DonorController::class, 'dashboard']);
Route::post('/donor/dashboard',[RazorpayController::class, 'Initiate']);

Route::get('/donor/donate', [DonorController::class, 'donate']);
Route::post('/donor/donate',[RazorpayController::class, 'Initiate']);

Route::get('/donor/stream', [DonorController::class, 'stream']);
Route::get('/donor/studentdetail/{id}', [DonorController::class, 'studentdetail']);


Route::get('/donor/thankyou',[RazorpayController::class, 'thankyou']);
Route::get('/donor/passbook',[DonorController::class, 'passbook']);

//Route::get('/donor/start', [DonorController::class, 'start']);
//Route::post('/donor/start',[RazorpayController::class, 'Initiate']);

Route::post('/payment-complete', [RazorpayController::class, 'Complete'])->name('Complete');
Route::post('/api/fetch-district', [DonorController::class, 'fetchDistrict']);

Route::get('/donor/logout', [DonorController::class, 'logout']);

// donor profile route
Route::match(['get', 'post'], 'donor/profile', [DonorController::class, 'profile'])->name('donor.profile');


// donor profile route
Route::match(['get', 'post'], 'donor/complete_dashboard', [DonorController::class, 'complete_dashboard'])->name('donor.complete_dashboard');
