@extends('layouts.advanced_form')
@section('content')
<section class="content">
    <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-12 col-md-6 col-sm-7">
                    <ul class="breadcrumb">                        
                        <li class="breadcrumb-item"><a href="">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="">Communication Template</a></li>
                        <li class="breadcrumb-item active">Edit Communication Template</li>
                    </ul>
                </div>
            </div>
        </div>
        @if (session('message'))
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <span class="text-center">{{ session('message') }}</span>
              </div>
            </div>
          </div>
        @endif
                                                  
        @if (session('error'))
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></but>
                <span class="text-center">{{ session('error') }}</span>
              </div>
            </div>
          </div>
        @endif
        
        <div class="row clearfix">
            <div class="col-lg-12">
                <div class="card">
                    <div class="header">
                        <h2>Edit Communication Template </h2>
                    </div>

                    <div class="body">
                        <form id="form_validation" action="{{ route('comm_tmpl.update') }}" method="POST">
                            @csrf
                            <input type="hidden" id="com_template_id" name="com_template_id" value="{{ @$partner_data->com_template_id }}" />
                            <div class="form-group">
                                <p class="m-t-10"> <b>User type</b> </p>
                                    <select class="form-control  show-tick" name="partner_name" id="partner_name" required>
                                        <option value="">--Select--</option>
                                        @foreach($result_partner['data'] as $partner)

                                        <option value="{{ $partner['partner_id'] }}" {{ $partner_data->partner_id==$partner['partner_id'] ? 'selected="selected"' : '' }}>{{ $partner['partner_name'] }} ({{ $partner['partner_id'] }})</option>
                                        @endforeach 
            
                                    </select> 
                            </div>  
                            <div class="form-group">
                                <p class="m-t-10"> <b>Template Name</b> </p>
                                    <input type="text" class="form-control" name="template_name" value= "{{ @$partner_data->template_name }}" required>
                            </div>
                            @error('template_name')
                              <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                            @enderror

                            <div class="form-group">
                                <p class="m-t-10"> <b>User type</b> </p>
                                    <select class="form-control  show-tick" name="com_type" required>
                                        <option value="">--Select--</option>
                                        <option value="SMS" {{ $partner_data->com_type=="SMS" ? 'selected="selected"' : '' }} >SMS</option>
                                        <option value="Email" {{ $partner_data->com_type=="Email" ? 'selected="selected"' : '' }} >Email</option>
                                    </select>   
                            </div>  

                            <div class="form-group">
                                <p class="m-t-10"> <b>Template Text</b> </p>
                                    <input type="text" class="form-control" name="template_text" value= "{{ @$partner_data->template_text }}">
                            </div>
                            
                            <button class="btn btn-raised btn-primary waves-effect" type="submit">Save</button>
                            <a href="{{ route('comm_tmpl.list') }}"><button class="btn btn-raised btn-primary waves-effect" type="button">Cancel</button></a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> 
@endsection