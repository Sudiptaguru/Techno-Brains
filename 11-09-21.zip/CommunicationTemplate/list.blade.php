@extends('layouts.advanced_form')
@section('content')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src='select2/dist/js/select2.min.js' type='text/javascript'></script>
<script type="text/javascript">
    $(document).ready(function () {
        $("#partner_name").on("change", function () {
            var name = $('#partner_name').find("option:selected").val();
            SearchData(name)
        });
    });
    function SearchData(name) {
        if (name.toUpperCase() == 'ALL') {
            $('#table11 tbody tr').show();
        } else {
            $('#table11 tbody tr:has(td)').each(function () {
                var rowName = $.trim($(this).find('td:eq(1)').text());
                if (name.toUpperCase() != 'ALL') {
                    if (rowName.toUpperCase() == name.toUpperCase()) {
                        $(this).show();
                    } else {
                        $(this).hide();
                    }
                } else if ($(this).find('td:eq(1)').text() != '' || $(this).find('td:eq(1)').text() != '') {
                    if (name != 'all') {
                        if (rowName.toUpperCase() == name.toUpperCase()) {
                            $(this).show();
                        } else {
                            $(this).hide();
                        }
                    }
                }

            });
        }
    }
</script>

<section class="content">   
    <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-12 col-md-6 col-sm-7">
                    <ul class="breadcrumb">                        
                        <li class="breadcrumb-item"><a href="">Dashboard</a></li>
                        <li class="breadcrumb-item active">Communication Template List</li>
                    </ul>
                </div>
            </div>
        </div>
        @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
        @endif
        @if (session('message'))
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <span class="text-center">{{ session('message') }}</span>
              </div>
            </div>
          </div>
        @endif

        @if (session('error'))
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <span class="text-center">{{ session('error') }}</span>
              </div>
            </div>
          </div>
        @endif
        <label><b>Partner Name</b></label>
        <select name="partner_name" id="partner_name" class="form-control col-md-6">
            <option value="">--Select--</option>
            @foreach($result_partner['data'] as $partner)

            <option value="{{ $partner['partner_id'] }}">{{ $partner['partner_name'] }} ({{ $partner['partner_id'] }})</option>
            @endforeach 
            
        </select>

        <p id="demo"></p>

        <input type="hidden" name="partner" id="partner" />
            <div style="clear:both"></div>
                        <div class="add-button text-right">
                            <a href="{{ route('comm_tmpl.add') }}"><button type="button" class="btn btn-raised btn-primary waves-effect">Add Communication Template</button></a>
                        </div>    
                        <div class="table-responsive">
                            <table id="table11" class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                <thead>
                                    <tr>
                                        <th>Partner Name</th>
                                        <th>Template Name</th>
                                        <th>Communication Type</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                
                                <tbody id="myTable">
                                    @foreach($result['data'] as $comm_tmpl)
                                    <tr>
                                        <td>@foreach($result_partner['data'] as $partner)<?php if($comm_tmpl['partner_id']==$partner['partner_id']){echo $partner['partner_name'];}?>@endforeach</td>
                                        <td>{{ $comm_tmpl['template_name'] }}</td>
                                        <td>{{ $comm_tmpl['com_type'] }}</td>
                                        <td><a class="demo-google-material-icon" href="{{ url('comm_tmpl_edit').'/'.$comm_tmpl['com_template_id'] }}"><i class="material-icons" title="Edit">edit</i></a>|<a class="demo-google-material-icon" href="{{ url('comm_tmpl_delete').'/'.$comm_tmpl['com_template_id'] }}" onclick="return confirm('Are you sure you want to delete this item ?');"><i class="material-icons" title="Delete">delete</i></a></td>
                                    </tr>
                                   @endforeach 
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection