DROP TABLE IF EXISTS `partner_user_mapping`;
CREATE TABLE `partner_user_mapping` (
  `partner_user_id` bigint(20) UNSIGNED NOT NULL,
  `partner_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `partner_user_mapping`
--
ALTER TABLE `partner_user_mapping`
  ADD PRIMARY KEY (`partner_user_id`),
  ADD KEY `partner_user_mapping_partner_id_foreign` (`partner_id`),
  ADD KEY `partner_user_mapping_user_id_foreign` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `partner_user_mapping`
--
ALTER TABLE `partner_user_mapping`
  MODIFY `partner_user_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;