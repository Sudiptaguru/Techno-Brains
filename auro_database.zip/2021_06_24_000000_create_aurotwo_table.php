<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAurotwoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
		Schema::create('teacher_master', function (Blueprint $table) {
            $table->bigIncrements('teacher_id');
            $table->unsignedBigInteger('user_id');
			$table->foreign('user_id')->references('user_id')->on('user_master')->onUpdate('cascade')->onDelete('cascade');
            $table->string('teacher_name');
            $table->string('mobile_no');
            $table->tinyInteger('mobile_no_verified')->default('0')->comment('0 -> Not Verified 1 -> Verified');
            $table->string('email_id');
            $table->tinyInteger('email_id_verified')->default('0')->comment('0 -> Not Verified 1 -> Verified');
            $table->string('device_token');
            $table->string('gender');
            $table->date('date_of_birth');
			$table->unsignedBigInteger('school_id');
			$table->foreign('school_id')->references('school_id')->on('school_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('country_id');
			$table->foreign('country_id')->references('country_id')->on('country_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('state_id');
			$table->foreign('state_id')->references('state_id')->on('state_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('district_id');
			$table->foreign('district_id')->references('district_id')->on('district_master')->onUpdate('cascade')->onDelete('cascade');
            $table->string('teacher_profile_pic');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
        Schema::create('document_type_master', function (Blueprint $table) {
            $table->bigIncrements('document_type_id');
            $table->string('document_type');
			$table->unsignedBigInteger('document_user_type');
			$table->foreign('document_user_type')->references('user_type_id')->on('user_type_master')->onUpdate('cascade')->onDelete('cascade');
			$table->enum('both_side_required',['Yes','No'])->default('No');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });		
		
        Schema::create('teacher_kyc_docs', function (Blueprint $table) {
            $table->bigIncrements('teacher_kyc_docs_id');
            $table->unsignedBigInteger('user_id');
			$table->foreign('user_id')->references('user_id')->on('user_master')->onUpdate('cascade')->onDelete('cascade');
            $table->unsignedBigInteger('document_type_id');
			$table->foreign('document_type_id')->references('document_type_id')->on('document_type_master')->onUpdate('cascade')->onDelete('cascade');
            $table->string('document_path');
			$table->enum('document_side',['Front','Back']);
            $table->integer('document_verified');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
        Schema::create('teacher_subject_grade_mapping', function (Blueprint $table) {
            $table->bigIncrements('grade_subject_id');
            $table->unsignedBigInteger('user_id');
			$table->foreign('user_id')->references('user_id')->on('user_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('grade_id');
			$table->foreign('grade_id')->references('grade_id')->on('grade_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('subject_id');
			$table->foreign('subject_id')->references('subject_id')->on('subject_master')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
        Schema::create('teacher_student_mapping', function (Blueprint $table) {
            $table->bigIncrements('teacher_student_mapping_id');
            $table->unsignedBigInteger('student_id');
			$table->foreign('student_id')->references('user_id')->on('user_master')->onUpdate('cascade')->onDelete('cascade');
            $table->unsignedBigInteger('teacher_id');
			$table->foreign('teacher_id')->references('user_id')->on('user_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('subject_id');
			$table->foreign('subject_id')->references('subject_id')->on('subject_master')->onUpdate('cascade')->onDelete('cascade');
			$table->enum('accepted_status',['0','1','2'])->default('0')->comment('0 -> Sent 1 -> Accepted 2 -> Rejected');
			$table->dateTime('accepted_date');
			$table->unsignedBigInteger('sent_by_type');
			$table->foreign('sent_by_type')->references('user_type_id')->on('user_type_master')->onUpdate('cascade')->onDelete('cascade');
			$table->enum('student_referral_status',['Created by Teacher','Referred by Teacher']);
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });		
		
        Schema::create('webinar_master', function (Blueprint $table) {
            $table->bigIncrements('webinar_id');
			$table->unsignedBigInteger('webinar_by_type');
			$table->foreign('webinar_by_type')->references('user_type_id')->on('user_type_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('webinar_for_type');
			$table->foreign('webinar_for_type')->references('user_type_id')->on('user_type_master')->onUpdate('cascade')->onDelete('cascade');
			$table->dateTime('webinar_start_time');
			$table->dateTime('webinar_end_time');
            $table->integer('max_participants');
            $table->string('webinar_topic');
            $table->unsignedBigInteger('webinar_language');
			$table->foreign('webinar_language')->references('language_id')->on('language_master')->onUpdate('cascade')->onDelete('cascade');
            $table->string('webinar_link');
            $table->timestamps();
        });
		
        Schema::create('webinar_booking_master', function (Blueprint $table) {
            $table->bigIncrements('booking_id');
            $table->unsignedBigInteger('webinar_id');
			$table->foreign('webinar_id')->references('webinar_id')->on('webinar_master')->onUpdate('cascade')->onDelete('cascade');
            $table->unsignedBigInteger('user_id');
			$table->foreign('user_id')->references('user_id')->on('user_master')->onUpdate('cascade')->onDelete('cascade');	
			$table->enum('status',['0','1'])->default('1')->comment('0 -> Attended 1 -> Not Attended');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
		});
		
		Schema::create('auro_partner_master', function (Blueprint $table) {	
            $table->bigIncrements('partner_id');
            $table->string('partner_name');
            $table->string('partner_source');
            $table->dateTime('registration_date');
			$table->enum('feature',['0','1'])->default('1')->comment('0 -> Yes 1 -> No');
			$table->enum('status',['0','1','2'])->default('1')->comment('0 -> Inactive 1 -> Active 2 -> Deleted');
			$table->string('partner_logo');
			$table->string('partner_website');
			$table->string('partner_internal_url');
			$table->string('required_params');
			$table->enum('mobile_no_verified', ['0', '1'])->default('0')->comment('0 -> Not Verified 1 -> Verified');
			$table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('partner_com_master', function (Blueprint $table) {	
            $table->bigIncrements('partner_com_id');
            $table->string('partner_name');
            $table->string('partner_logo');
            $table->text('partner_description');
			$table->unsignedBigInteger('partner_id');
			$table->foreign('partner_id')->references('partner_id')->on('auro_partner_master')->onUpdate('cascade')->onDelete('cascade');
			$table->enum('status',['0','1','2'])->default('1')->comment('0 -> Inactive 1 -> Active 2 -> Deleted');
			$table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('partner_user_mapping', function (Blueprint $table) {	
            $table->bigIncrements('partner_user_id');
			$table->unsignedBigInteger('partner_com_id');
			$table->foreign('partner_com_id')->references('partner_com_id')->on('partner_com_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('user_id');
			$table->foreign('user_id')->references('user_id')->on('user_master')->onUpdate('cascade')->onDelete('cascade');
			$table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });		
		
		Schema::create('partner_filter_master', function (Blueprint $table) {	
            $table->bigIncrements('partner_filter_master');
			$table->unsignedBigInteger('partner_com_id');
			$table->foreign('partner_com_id')->references('partner_com_id')->on('partner_com_master')->onUpdate('cascade')->onDelete('cascade');
            $table->string('filter_name');
            $table->string('filter_data_type');
			$table->enum('status',['0','1','2'])->default('1')->comment('0 -> Inactive 1 -> Active 2 -> Deleted');
			$table->integer('field_value_sequence');
			$table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('com_status_master', function (Blueprint $table) {
            $table->bigIncrements('com_status_id');
            $table->string('status_text');
            $table->text('status_remark');
			$table->enum('status_type', ['Delivery', 'Action']);
			$table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		 Schema::create('com_vendor_master', function (Blueprint $table) {
            $table->bigIncrements('com_vendor_id');
            $table->string('vendor_name');
            $table->string('service_name');
            $table->string('vendor_contact_name');
            $table->string('vendor_contact_no');
            $table->string('vendor_contact_email');
			$table->enum('status',['0','1','2'])->default('1')->comment('0 -> Inactive 1 -> Active 2 -> Deleted');
			$table->text('vendor_remark');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('com_response_code_master', function (Blueprint $table) {
            $table->bigIncrements('com_error_code_id');
            $table->unsignedBigInteger('com_vendor_id');
			$table->foreign('com_vendor_id')->references('com_vendor_id')->on('com_vendor_master')->onUpdate('cascade')->onDelete('cascade');
            $table->string('response_code');
			$table->unsignedBigInteger('com_status_id');
			$table->foreign('com_status_id')->references('com_status_id')->on('com_status_master')->onUpdate('cascade')->onDelete('cascade');
			$table->text('remark');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		            
		Schema::create('partner_com_sender_master', function (Blueprint $table) {
            $table->bigIncrements('com_sender_id');
            $table->string('sendered_text');
            $table->unsignedBigInteger('com_vendor_id');
			$table->foreign('com_vendor_id')->references('com_vendor_id')->on('com_vendor_master')->onUpdate('cascade')->onDelete('cascade');
			$table->enum('com_type', ['SMS', 'Email']);
			$table->enum('status',['0','1','2'])->default('1')->comment('0 -> Inactive 1 -> Active 2 -> Deleted');
			$table->unsignedBigInteger('partner_com_id');
			$table->foreign('partner_com_id')->references('partner_com_id')->on('partner_com_master')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		                                                                                        
		Schema::create('vendor_template_master', function (Blueprint $table) {
            $table->bigIncrements('vendor_template_id');
            $table->unsignedBigInteger('com_vendor_id');
			$table->foreign('com_vendor_id')->references('com_vendor_id')->on('com_vendor_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('partner_id');
			$table->foreign('partner_id')->references('partner_id')->on('auro_partner_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('sender_id');
			$table->foreign('sender_id')->references('com_sender_id')->on('partner_com_sender_master')->onUpdate('cascade')->onDelete('cascade');
			$table->text('template_text');
			$table->enum('status',['0','1','2'])->default('1')->comment('0 -> Inactive 1 -> Active 2 -> Deleted');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('com_template_master', function (Blueprint $table) {
            $table->bigIncrements('com_template_id');
            $table->string('template_name');
			$table->enum('com_type', ['SMS', 'Email']);
			$table->text('template_text');
			$table->enum('status',['0','1','2'])->default('1')->comment('0 -> Inactive 1 -> Active 2 -> Deleted');
			$table->unsignedBigInteger('partner_id');
			$table->foreign('partner_id')->references('partner_id')->on('auro_partner_master')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });	
		
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
		Schema::dropIfExists('teacher_master');
        Schema::dropIfExists('document_type_master');
        Schema::dropIfExists('teacher_kyc_docs');
        Schema::dropIfExists('teacher_subject_grade_mapping');
        Schema::dropIfExists('teacher_student_mapping');
        Schema::dropIfExists('webinar_master');
        Schema::dropIfExists('webinar_booking_master');
        Schema::dropIfExists('auro_partner_master');
		Schema::dropIfExists('partner_com_master');
        Schema::dropIfExists('partnert_user_mapping');
        Schema::dropIfExists('partner_filter_master');
        Schema::dropIfExists('com_status_master');
        Schema::dropIfExists('com_vendor_master');
        Schema::dropIfExists('com_response_code_master');
        Schema::dropIfExists('partner_com_sender_master');
        Schema::dropIfExists('vendor_template_master');
        Schema::dropIfExists('com_template_master');
    }
}
