<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAurooneTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
		Schema::create('api_authentication', function (Blueprint $table) {	
            $table->bigIncrements('id');
            $table->string('server_ip');
            $table->string('secretid');
            $table->string('secretkey');
			$table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('user_type_master', function (Blueprint $table) {	
            $table->bigIncrements('user_type_id');
            $table->string('user_type_name');
			$table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('role_master', function (Blueprint $table) {	
            $table->bigIncrements('role_id');
            $table->string('role_name');
			$table->unsignedBigInteger('user_type_id');
			$table->foreign('user_type_id')->references('user_type_id')->on('user_type_master')->onUpdate('cascade')->onDelete('cascade');
			$table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('user_master', function (Blueprint $table) {	
            $table->bigIncrements('user_id');
			$table->unsignedBigInteger('user_type_id');
			$table->foreign('user_type_id')->references('user_type_id')->on('user_type_master')->onUpdate('cascade')->onDelete('cascade');
            $table->string('user_name');
            $table->string('password');
			$table->unsignedBigInteger('role_id');
			$table->foreign('role_id')->references('role_id')->on('role_master')->onUpdate('cascade')->onDelete('cascade');
			$table->enum('status',['0','1','2'])->default('1')->comment('0 -> Inactive 1 -> Active 2 -> Deleted');
			$table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
        Schema::create('language_master', function (Blueprint $table) {
            $table->bigIncrements('language_id');
            $table->string('language_name');
            $table->string('translated_language_name');
			$table->enum('status',['0','1','2'])->default('1')->comment('0 -> Inactive 1 -> Active 2 -> Deleted');
			$table->unsignedBigInteger('created_by');
			$table->foreign('created_by')->references('user_id')->on('user_master')->onUpdate('cascade')->onDelete('cascade');
            $table->unsignedBigInteger('updated_by');
			$table->foreign('updated_by')->references('user_id')->on('user_master')->onUpdate('cascade')->onDelete('cascade');
            $table->timestamps();
        });
		
		Schema::create('donor_master', function (Blueprint $table) {
            $table->bigIncrements('donor_id');
			$table->unsignedBigInteger('user_id');
            $table->string('donor_name');
			$table->enum('donor_type',['Individual','Institutional'])->default('Individual');
            $table->unsignedBigInteger('preferred_language');
			$table->foreign('preferred_language')->references('language_id')->on('language_master')->onUpdate('cascade')->onDelete('cascade');
			$table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		 Schema::create('country_master', function (Blueprint $table) {
            $table->bigIncrements('country_id');
            $table->string('country_name');
            $table->string('translated_country_name');
			$table->enum('status',['0','1','2'])->default('1')->comment('0 -> Inactive 1 -> Active 2 -> Deleted');
            $table->unsignedBigInteger('official_language_id');
			$table->foreign('official_language_id')->references('language_id')->on('language_master')->onUpdate('cascade')->onDelete('cascade');
			$table->binary('country_flag');
			$table->integer('mobile_prefix');
			$table->integer('mobile_max_length');
			$table->integer('mobile_min_length');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('state_master', function (Blueprint $table) {
            $table->bigIncrements('state_id');
            $table->string('state_name');
			$table->string('translated_state_name');
            $table->unsignedBigInteger('country_id');
			$table->foreign('country_id')->references('country_id')->on('country_master')->onUpdate('cascade')->onDelete('cascade');
			$table->enum('status',['0','1','2'])->default('1')->comment('0 -> Inactive 1 -> Active 2 -> Deleted');
			$table->unsignedBigInteger('official_language_id');
			$table->foreign('official_language_id')->references('language_id')->on('language_master')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('district_master', function (Blueprint $table) {
            $table->bigIncrements('district_id');
            $table->string('district_name');
			$table->string('translated_district_name');
            $table->unsignedBigInteger('state_id');
			$table->foreign('state_id')->references('state_id')->on('state_master')->onUpdate('cascade')->onDelete('cascade');
            $table->unsignedBigInteger('official_language_id');
			$table->foreign('official_language_id')->references('language_id')->on('language_master')->onUpdate('cascade')->onDelete('cascade');
			$table->enum('status',['0','1','2'])->default('1')->comment('0 -> Inactive 1 -> Active 2 -> Deleted');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('donor_individual_details', function (Blueprint $table) {
            $table->bigIncrements('individual_donor_id');
			$table->unsignedBigInteger('donor_id');
			$table->foreign('donor_id')->references('donor_id')->on('donor_master')->onUpdate('cascade')->onDelete('cascade');
			$table->string('mobile_no');
			$table->unsignedBigInteger('country_code')->nullable();;
			$table->foreign('country_code')->references('country_id')->on('country_master')->onUpdate('cascade')->onDelete('cascade');
			$table->tinyInteger('mobile_no_verified')->default('0')->comment('0 -> Yes 1 -> No');
			$table->string('whatsapp_no');
			$table->unsignedBigInteger('whatsapp_country_code')->nullable();;
			$table->foreign('whatsapp_country_code')->references('country_id')->on('country_master')->onUpdate('cascade')->onDelete('cascade');
			$table->string('email_id');
			$table->tinyInteger('email_id_verified')->default('0')->comment('0 -> Yes 1 -> No');
			$table->unsignedBigInteger('country_id')->nullable();;
			$table->foreign('country_id')->references('country_id')->on('country_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('state_id')->nullable();;
			$table->foreign('state_id')->references('state_id')->on('state_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('district_id')->nullable();;
			$table->foreign('district_id')->references('district_id')->on('district_master')->onUpdate('cascade')->onDelete('cascade');
			$table->text('address_line1');
			$table->string('nationality');
			$table->string('pan_card');
			$table->string('pan_card_no');
			$table->string('date_of_birth');
			$table->string('gender');
			$table->string('profile_pic');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('grade_master', function (Blueprint $table) {
            $table->bigIncrements('grade_id');
            $table->string('grade_name');
			$table->enum('status',['0','1','2'])->default('1')->comment('0 -> Inactive 1 -> Active 2 -> Deleted');
            $table->integer('priority');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('subject_type_master', function (Blueprint $table) {
            $table->bigIncrements('subject_type_id');
            $table->string('subject_type_name');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		 Schema::create('subject_master', function (Blueprint $table) {
            $table->bigIncrements('subject_id');
            $table->unsignedBigInteger('subject_type_id');
			$table->foreign('subject_type_id')->references('subject_type_id')->on('subject_type_master')->onUpdate('cascade')->onDelete('cascade');
			$table->enum('status',['0','1','2'])->default('1')->comment('0 -> Inactive 1 -> Active 2 -> Deleted');
			$table->integer('priority');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('currency_master', function (Blueprint $table) {
            $table->bigIncrements('currency_id');
			$table->string('currency_name');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });	
		
		Schema::create('donor_stream_master', function (Blueprint $table) {
            $table->bigIncrements('stream_id');
			$table->unsignedBigInteger('donor_id');
			$table->foreign('donor_id')->references('donor_id')->on('donor_master')->onUpdate('cascade')->onDelete('cascade');
			$table->enum('donation_frequency',['Onetime','Monthly','Querterly','Halfyearly','Yearly']);
			$table->unsignedBigInteger('scholarship_currency');
			$table->foreign('scholarship_currency')->references('currency_id')->on('currency_master')->onUpdate('cascade')->onDelete('cascade');
			$table->string('stream_name');
			$table->string('first_payment_date');
			$table->string('frequency_amount');
			$table->string('last_payment_date');
			$table->enum('status',['0','1','2'])->default('1')->comment('0 -> Inactive 1 -> Active 2 -> Deleted');
			$table->text('grade_preference');
			$table->text('subject_preference');
			$table->text('geographic_preference');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });	
		
		Schema::create('donor_transaction_type_master', function (Blueprint $table) {
            $table->bigIncrements('donor_transaction_type_id');
			$table->string('transaction_type_name');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });	
		
		Schema::create('donor_stream_subject_mapping', function (Blueprint $table) {
            $table->bigIncrements('donor_subject_mapping_id');
			$table->unsignedBigInteger('stream_id');
			$table->foreign('stream_id')->references('stream_id')->on('donor_stream_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('subject_id');
			$table->foreign('subject_id')->references('subject_id')->on('subject_master')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });	
		
		Schema::create('donor_stream_grade_mapping', function (Blueprint $table) {
            $table->bigIncrements('donor_grade_mapping_id');
			$table->unsignedBigInteger('stream_id');
			$table->foreign('stream_id')->references('stream_id')->on('donor_stream_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('grade_id');
			$table->foreign('grade_id')->references('grade_id')->on('grade_master')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });	
		
		Schema::create('donor_stream_geography_mapping', function (Blueprint $table) {
            $table->bigIncrements('donor_geography_mapping_id');
			$table->unsignedBigInteger('stream_id');
			$table->foreign('stream_id')->references('stream_id')->on('donor_stream_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('state_id');
			$table->foreign('state_id')->references('state_id')->on('state_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('district_id');
			$table->foreign('district_id')->references('district_id')->on('district_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('country_id');
			$table->foreign('country_id')->references('country_id')->on('country_master')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('donor_transaction_log', function (Blueprint $table) {
            $table->bigIncrements('transaction_id');
			$table->unsignedBigInteger('donor_id');
			$table->foreign('donor_id')->references('donor_id')->on('donor_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('stream_id');
			$table->foreign('stream_id')->references('stream_id')->on('donor_stream_master')->onUpdate('cascade')->onDelete('cascade');
			$table->decimal('amount', 10, 2);
			$table->unsignedBigInteger('currency_id');
			$table->foreign('currency_id')->references('currency_id')->on('currency_master')->onUpdate('cascade')->onDelete('cascade');
			$table->enum('status',['Success','Fail','Pending'])->default('Pending');
			$table->enum('transaction_type',['Debit','Credit']);
			$table->unsignedBigInteger('transaction_type_id');
			$table->foreign('transaction_type_id')->references('donor_transaction_type_id')->on('donor_transaction_type_master')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });	

		Schema::create('donor_transaction_quiz_mapping', function (Blueprint $table) {
            $table->bigIncrements('donor_transaction_quiz_mapping_id');
			$table->unsignedBigInteger('transaction_id');
			$table->foreign('transaction_id')->references('transaction_id')->on('donor_transaction_log')->onUpdate('cascade')->onDelete('cascade');
			$table->integer('registration_id');
			$table->integer('quiz_id');
			$table->unsignedBigInteger('subject_id');
			$table->foreign('subject_id')->references('subject_id')->on('subject_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('grade_id');
			$table->foreign('grade_id')->references('grade_id')->on('grade_master')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });	
		
		
		Schema::create('menu_master', function (Blueprint $table) {
            $table->bigIncrements('menu_id');
			$table->integer('menu_type');
			$table->integer('main_menu_id');
			$table->binary('menu_icon');
			$table->string('menu_link');
			$table->enum('status',['0','1','2'])->default('1')->comment('0 -> Inactive 1 -> Active 2 -> Deleted');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('menu_translation_master', function (Blueprint $table) {
            $table->bigIncrements('menu_translation_id');
			$table->unsignedBigInteger('menu_id');
			$table->foreign('menu_id')->references('menu_id')->on('menu_master')->onUpdate('cascade')->onDelete('cascade');
			$table->string('menu_text');
			$table->unsignedBigInteger('language_id');
			$table->foreign('language_id')->references('language_id')->on('language_master')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('role_menu_mapping', function (Blueprint $table) {
            $table->bigIncrements('role_menu_id');
			$table->unsignedBigInteger('role_id');
			$table->foreign('role_id')->references('role_id')->on('role_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('menu_id');
			$table->foreign('menu_id')->references('menu_id')->on('menu_master')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('pre_registration_master', function (Blueprint $table) {
            $table->bigIncrements('pre_registration_id');
			$table->unsignedBigInteger('user_type_id');
			$table->foreign('user_type_id')->references('user_type_id')->on('user_type_master')->onUpdate('cascade')->onDelete('cascade');
			$table->string('mobile_no');
			$table->unsignedBigInteger('country_id');
			$table->foreign('country_id')->references('country_id')->on('country_master')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('otp_log', function (Blueprint $table) {
            $table->bigIncrements('otp_id');
			$table->string('mobile_no');
			$table->unsignedBigInteger('country_id');
			$table->foreign('country_id')->references('country_id')->on('country_master')->onUpdate('cascade')->onDelete('cascade');
			$table->string('otp');
			$table->enum('otp_type',['Email','SMS']);
			$table->string('email_id');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('otp_log_history', function (Blueprint $table) {
            $table->bigIncrements('otp_history_id');
			$table->string('mobile_no');
			$table->string('otp');
			$table->enum('otp_type',['Email','SMS']);
			$table->string('email_id');
			$table->unsignedBigInteger('country_id');
			$table->foreign('country_id')->references('country_id')->on('country_master')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('system_text_master', function (Blueprint $table) {
            $table->bigIncrements('stm_id');
			$table->string('object_type');
			$table->string('object_category');
			$table->string('remarks');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('system_text_translation_master', function (Blueprint $table) {
            $table->bigIncrements('stt_id');
			$table->unsignedBigInteger('stm_id');
			$table->foreign('stm_id')->references('stm_id')->on('system_text_master')->onUpdate('cascade')->onDelete('cascade');
			$table->string('system_text');
			$table->unsignedBigInteger('language_id');
			$table->foreign('language_id')->references('language_id')->on('language_master')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('subject_translation_master', function (Blueprint $table) {
            $table->bigIncrements('subject_translation_id');
			$table->unsignedBigInteger('subject_id');
			$table->foreign('subject_id')->references('subject_id')->on('subject_master')->onUpdate('cascade')->onDelete('cascade');
			$table->string('subject_name');
			$table->unsignedBigInteger('language_id');
			$table->foreign('language_id')->references('language_id')->on('language_master')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('grade_subject_mapping', function (Blueprint $table) {
            $table->bigIncrements('gsm_id');
			$table->unsignedBigInteger('subject_id');
			$table->foreign('subject_id')->references('subject_id')->on('subject_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('grade_id');
			$table->foreign('grade_id')->references('grade_id')->on('grade_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('language_id');
			$table->foreign('language_id')->references('language_id')->on('language_master')->onUpdate('cascade')->onDelete('cascade');
			$table->enum('status',['0','1','2','3'])->default('1')->comment('0 -> Inactive 1 -> Active 2 -> With Validity Active 3 -> With Validity Inactive');
			$table->dateTime('validity');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('school_master', function (Blueprint $table) {
            $table->bigIncrements('school_id');
			$table->string('school_name');
			$table->string('udise_code');
			$table->unsignedBigInteger('country_id');
			$table->foreign('country_id')->references('country_id')->on('country_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('state_id');
			$table->foreign('state_id')->references('state_id')->on('state_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('district_id');
			$table->foreign('district_id')->references('district_id')->on('district_master')->onUpdate('cascade')->onDelete('cascade');
			$table->string('village_name');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('cert_template_master', function (Blueprint $table) {
            $table->bigIncrements('cert_template_id');
			$table->binary('cert_template_html');
			$table->unsignedBigInteger('issued_by_type');
			$table->foreign('issued_by_type')->references('user_type_id')->on('user_type_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('issued_to_type');
			$table->foreign('issued_to_type')->references('user_type_id')->on('user_type_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('cert_language_id');
			$table->foreign('cert_language_id')->references('language_id')->on('language_master')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('no_of_variable_s');
            $table->integer('no_of_variable_u');
			$table->enum('status',['0','1','2'])->default('1')->comment('0 -> Inactive 1 -> Active 2 -> Deleted');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('cert_variable_type_master', function (Blueprint $table) {
            $table->bigIncrements('variable_type_id');
			$table->enum('variable_input_type',['U','S'])->default('U');
			$table->string('object_type');
			$table->string('api_name');
			$table->string('remarks');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('cert_variable_type_translation_master', function (Blueprint $table) {
            $table->bigIncrements('variable_translation_id');
			$table->unsignedBigInteger('variable_type_id');
			$table->foreign('variable_type_id')->references('variable_type_id')->on('cert_variable_type_master')->onUpdate('cascade')->onDelete('cascade');
			$table->string('variable_text');
			$table->unsignedBigInteger('language_id');
			$table->foreign('language_id')->references('language_id')->on('language_master')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('cert_variable_master', function (Blueprint $table) {
            $table->bigIncrements('cert_variable_id');
			$table->unsignedBigInteger('cert_template_id');
			$table->foreign('cert_template_id')->references('cert_template_id')->on('cert_template_master')->onUpdate('cascade')->onDelete('cascade');
			$table->integer('variable_number');
			$table->enum('variable_type',['U','S'])->default('U');
			$table->unsignedBigInteger('variable_type_id');
			$table->foreign('variable_type_id')->references('variable_type_id')->on('cert_variable_type_master')->onUpdate('cascade')->onDelete('cascade');
			$table->tinyInteger('variable_mandatory')->default('0')->comment('0 -> Non Mandatory 1 -> Mandatory');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
		Schema::create('cert_issuer_mapping', function (Blueprint $table) {
            $table->bigIncrements('issuer_mapping_id');
			$table->unsignedBigInteger('cert_template_id');
			$table->foreign('cert_template_id')->references('cert_template_id')->on('cert_template_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('issuer_user_id');
			$table->foreign('issuer_user_id')->references('user_id')->on('user_master')->onUpdate('cascade')->onDelete('cascade');
			$table->binary('cert_i_html');
			$table->enum('auth_status',['A','D','P'])->default('P')->comment('A -> Approved D -> Disapproved P -> Pending');
			$table->string('auth_remarks');
			$table->unsignedBigInteger('auth_by_id');
			$table->foreign('auth_by_id')->references('user_id')->on('user_master')->onUpdate('cascade')->onDelete('cascade');
			$table->dateTime('date_of_auth');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
				
		Schema::create('cert_user_master', function (Blueprint $table) {
            $table->bigIncrements('cert_id');
			$table->unsignedBigInteger('issued_to_user_id');
			$table->foreign('issued_to_user_id')->references('user_id')->on('user_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('issued_to_type');
			$table->foreign('issued_to_type')->references('user_type_id')->on('user_type_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('issuer_mapping_id');
			$table->foreign('issuer_mapping_id')->references('issuer_mapping_id')->on('cert_issuer_mapping')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('issued_by_id');
			$table->foreign('issued_by_id')->references('user_id')->on('user_master')->onUpdate('cascade')->onDelete('cascade');
			$table->unsignedBigInteger('issued_by_type');
			$table->foreign('issued_by_type')->references('user_type_id')->on('user_type_master')->onUpdate('cascade')->onDelete('cascade');
			$table->binary('cert_u_html');
			$table->integer('total_downloads');
			$table->integer('total_share');
			$table->enum('status',['I','A'])->default('I')->comment('I -> Inactive A -> Active');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
		
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('api_authentication');
        Schema::dropIfExists('user_type_master');
        Schema::dropIfExists('role_master');
        Schema::dropIfExists('user_master');
        Schema::dropIfExists('language_master');
        Schema::dropIfExists('donor_master');
        Schema::dropIfExists('country_master');
        Schema::dropIfExists('state_master');
        Schema::dropIfExists('district_master');
        Schema::dropIfExists('donor_individual_details');
        Schema::dropIfExists('grade_master');
        Schema::dropIfExists('subject_type_master');
        Schema::dropIfExists('subject_master');
        Schema::dropIfExists('donor_stream_master');
        Schema::dropIfExists('currency_master');
        Schema::dropIfExists('donor_transaction_type_master');
        Schema::dropIfExists('donor_stream_subject_mapping');
        Schema::dropIfExists('donor_stream_grade_mapping');
        Schema::dropIfExists('donor_stream_geography_mapping');
        Schema::dropIfExists('donor_transaction_log');
        Schema::dropIfExists('donor_transaction_quiz_mapping');
        Schema::dropIfExists('menu_master');
        Schema::dropIfExists('menu_translation_master');
        Schema::dropIfExists('role_menu_mapping');
        Schema::dropIfExists('pre_registration_master');
        Schema::dropIfExists('otp_log');
        Schema::dropIfExists('otp_log_history');
        Schema::dropIfExists('system_text_master');
        Schema::dropIfExists('system_text_translation_master');
        Schema::dropIfExists('subject_translation_master');
        Schema::dropIfExists('grade_subject_mapping');
        Schema::dropIfExists('school_master');
        Schema::dropIfExists('cert_template_master');
        Schema::dropIfExists('cert_variable_type_master');
        Schema::dropIfExists('cert_variable_type_translation_master');
        Schema::dropIfExists('cert_variable_master');
        Schema::dropIfExists('cert_issuer_mapping');
        Schema::dropIfExists('cert_user_master');
        
    }
}
