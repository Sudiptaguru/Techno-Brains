<?php
ob_start();
include("../db.php");
include("../functions.php");
//require (__DIR__.'/../../../helper.php');
//include("../helper.php");
$headers = apache_request_headers();
$return = array();
$returndata = array();
$dataarr=array();
// $_REQUEST['start'] = isset($_POST['page']) ? $_POST['page'] : 1;
//$return["success"]="failure";
$server_ip=$_SERVER['SERVER_ADDR'];
//$server_ip='45.64.104.64';

$lang_code =  strtolower($headers["Lang-Code"]);

if($lang_code!="")
{
	if(file_get_contents("../".$lang_code.".php"))
	{
		include("../".$lang_code.".php");
	}
	else
	{
		include("../english.php");		
	}
}
else
{
	include("../english.php");
}


$allowedMethods = array('POST');
$requestMethod = strtoupper($_SERVER['REQUEST_METHOD']);

if(!in_array($requestMethod, $allowedMethods))
{	
	http_response_code(405);
	$return["response_code"]=405;
	$return["message"]=$AuroLangConvert["405.1"];
	echo json_encode($return,JSON_UNESCAPED_UNICODE);
	exit;			
}




if(isset($headers["Secret-Id"]) && isset($headers["Secret-Key"]) && isset($headers["Lang-Code"]))
{
	$secretid =  $headers["Secret-Id"];
	$secretkey =  $headers["Secret-Key"];
	
	if(CheckAuthentication($secretid, $secretkey, $server_ip)) 
	{
		$json = file_get_contents('php://input');
		
		
		if(trim($json)=='')
		{
			
			$return["status"]="fail";
			$return["error"]="true";
			$return["response_code"]=400;					
			$return["message"]=$AuroLangConvert["400.1"];		
		}
		else 
		{

			$a = fopen("ug.txt","w");

			foreach($_REQUEST as $k=>$v)
			{
				if(is_array($v))
				{
					foreach($v as $kk=>$vv)
					{
						if(is_array($vv))
						{
							foreach($vv as $kkk=>$vvv)
							{
								fwrite($a,$k."===".$kk."===".$kkk."==".$vvv."\n");
							}
						}
						else
						{
							fwrite($a,$k."===".$kk."==".$vv."\n");
						}
					}
				}
				else
				{
					fwrite($a,$k."==".$v."\n");
				}

			}
			
			$aColumns = array( 'cvm.com_vendor_id', 'cvm.vendor_name', 'cvm.service_name', 'cvm.vendor_contact_name', 'cvm.vendor_contact_no', 'cvm.vendor_contact_email', 'cvm.status', 'cvm.vendor_remark', 'cvm.created_by', 'cvm.updated_by', 'cvm.created_at',  'cvm.updated_at');
			$sIndexColumn = "cvm.com_vendor_id";
			$sTable = "com_vendor_master cvm";
			$start=$_REQUEST['start'];
			fwrite($a,$sTable."\n");
			
			$sLimit = "";
			if ( isset( $_REQUEST['start'] ) && $_REQUEST['length'] != '-1' )
			{
				$sLimit = "LIMIT ".(int)$_REQUEST['start'].", ".(int)$_REQUEST['length'];
			}
			$orderbycol = empty($_REQUEST['order'][0]['column']) ? '' : $_REQUEST['order'][0]['column'];
			$orderby = empty($aColumns[$orderbycol]) ? 'cvm.com_vendor_id' : $aColumns[$orderbycol];
			$orderdir = empty($_REQUEST['order'][0]['dir']) ? 'desc' : $_REQUEST['order'][0]['dir'] ;

			fwrite($a,$orderdir."\n");
			fwrite($a,"OBY  ".$orderby."\n");
			
			$sWhere = " WHERE cvm.com_vendor_id !='0' ";

			if ( $_REQUEST['search']['value']!= "" )
			{
				if($_REQUEST['search']['value']=='Active')
				{
					$searchval = "No";
				}
				else if($_REQUEST['search']['value']=='Inactive')
				{
					$searchval = "Yes";
				}
				else
				{
					$searchval = $_REQUEST['search']['value'];
				}
				$sWhere .= " WHERE  (";
				
				for ( $i=0 ; $i<count($aColumns) ; $i++ )
				{
					$sWhere .= $aColumns[$i]." LIKE '%".mysqli_real_escape_string($con, $searchval )."%' OR ";
				}
				$sWhere = substr_replace( $sWhere, "", -3 );
				$sWhere .= ')';
			}
			fwrite($a,$sWhere."\n");
			fwrite($a,"========================================================================\n");
			
			$sQuery = "
				SELECT SQL_CALC_FOUND_ROWS ".str_replace(" , ", " ", implode(", ", $aColumns))."
				FROM   $sTable
				$sWhere
				order by $orderby $orderdir 
				 $sLimit 
			";

			//echo $sQuery;
			//die ;
			//exit();


			fwrite($a,$sQuery."\n");
			fwrite($a,"========================================================================\n");
			$rResult = mysqli_query($con, $sQuery ) or die(mysqli_error());
			
			

			
			/* Data set length after filtering */
			$sQuery = "SELECT FOUND_ROWS()";
			fwrite($a,$sQuery."\n");
			fwrite($a,"========================================================================\n");
			
			$rResultFilterTotal = mysqli_query($con, $sQuery ) or die(mysqli_error());
			$aResultFilterTotal = mysqli_fetch_array($rResultFilterTotal);
			$iFilteredTotal = $aResultFilterTotal[0];
			
			/* Total data set length */
			$sQuery = "
				SELECT COUNT(".$sIndexColumn.")
				FROM   $sTable $sWhere";
			
			//die;	
			fwrite($a,$sQuery."\n");
			fwrite($a,"========================================================================\n");

			$rResultTotal = mysqli_query( $con, $sQuery ) or die(mysqli_error());
			$aResultTotal = mysqli_fetch_array($rResultTotal);
			$iTotal = $aResultTotal[0];
			
			/*
			 * Output
			 */
			 
			$return = array(
				"sEcho" => intval($_REQUEST['sEcho']),
				"iTotalRecords" => $iTotal,
				"iTotalDisplayRecords" => $iFilteredTotal,
				"status"=>"success",
				"error"=>"false",
				"response_code"=>200,
				"message"=>$AuroLangConvert["200.12"],
				"aaData" => array()
			);
			$sl_no =$start+1;

			$xx = 0;
			while ( $aRow = mysqli_fetch_array( $rResult ) )
			{
				$returndata = array();	
				
				//$aColumns = array('cvm.com_vendor_id', 'cvm.vendor_name', 'cvm.service_name', 'cvm.vendor_contact_name', 'cvm.vendor_contact_no', 'cvm.vendor_contact_email', 'cvm.status', 'cvm.vendor_remark', 'cvm.created_by', 'cvm.updated_by', 'cvm.created_at',  'cvm.updated_at', 'apm.partner_name');

				$com_vendor_id = stripslashes($aRow["com_vendor_id"]);
				$vendor_name = stripslashes($aRow["vendor_name"]);
				$service_name = stripslashes($aRow["service_name"]);
				$vendor_contact_name = stripslashes($aRow["vendor_contact_name"]);
				$vendor_contact_no = stripslashes($aRow["vendor_contact_no"]);
				$vendor_contact_email = stripslashes($aRow["vendor_contact_email"]);
				$status = stripslashes($aRow["status"]);
				$vendor_remark = stripslashes($aRow["vendor_remark"]);
				$created_by =  stripslashes($aRow["created_by"]);
				$updated_by =  stripslashes($aRow["updated_by"]);
				$partner_name = stripslashes($aRow["partner_name"]);
				
				
				
				
				
				//$output['aaData'][] = $row;
				$aaa = "abccc";
				
				$returndata[]=$sl_no;
				$returndata[]=$vendor_name;
				$returndata[]=$service_name;
				$returndata[]=$vendor_contact_name;
				$returndata[]=$vendor_contact_no;
				$returndata[]=$vendor_contact_email;
				$returndata[]=$status;
				$returndata[]=$vendor_remark;
				$returndata[]=$created_by;
				$returndata[]=$updated_by;
				$returndata[]='<a href='.$aaa.'>View</a>';
				
				$return['aaData'][] = $returndata;
				$sl_no++;
			}
			fclose($a);	
					
		}
	}
	else
	{
		$return["status"]="fail";
		$return["error"]="true";
		$return["response_code"] = 403;	
		$return["message"] = $AuroLangConvert["403.1"];
	}
}
else
{
	$return["status"]="fail";
	$return["error"]="true";
	$return["response_code"] = 403;	
	$return["message"] = $AuroLangConvert["403.1"];	
}
echo json_encode($return,JSON_UNESCAPED_UNICODE);
?>