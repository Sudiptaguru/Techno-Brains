<?php
ob_start();
include("../db.php");
include("../functions.php");
//require (__DIR__.'/../../../helper.php');
//include("../helper.php");
$headers = apache_request_headers();
$return = array();
$returndata = array();
$dataarr=array();
// $_REQUEST['start'] = isset($_POST['page']) ? $_POST['page'] : 1;
//$return["success"]="failure";
$server_ip=$_SERVER['SERVER_ADDR'];
//$server_ip='45.64.104.64';

$lang_code =  strtolower($headers["Lang-Code"]);

if($lang_code!="")
{
	if(file_get_contents("../".$lang_code.".php"))
	{
		include("../".$lang_code.".php");
	}
	else
	{
		include("../english.php");		
	}
}
else
{
	include("../english.php");
}


$allowedMethods = array('POST');
$requestMethod = strtoupper($_SERVER['REQUEST_METHOD']);

if(!in_array($requestMethod, $allowedMethods))
{	
	http_response_code(405);
	$return["response_code"]=405;
	$return["message"]=$AuroLangConvert["405.1"];
	echo json_encode($return,JSON_UNESCAPED_UNICODE);
	exit;			
}




if(isset($headers["Secret-Id"]) && isset($headers["Secret-Key"]) && isset($headers["Lang-Code"]))
{
	$secretid =  $headers["Secret-Id"];
	$secretkey =  $headers["Secret-Key"];
	
	if(CheckAuthentication($secretid, $secretkey, $server_ip)) 
	{
		$json = file_get_contents('php://input');
		
		
		if(trim($json)=='')
		{
			
			$return["status"]="fail";
			$return["error"]="true";
			$return["response_code"]=400;					
			$return["message"]=$AuroLangConvert["400.1"];		
		}
		else 
		{
				if($_REQUEST['partner_id']=='')
				{
					$return["status"] = "fail";
					$return["error"] = "true";
					$return["response_code"] = 4001;			
					$return["message"] = $AuroLangConvert["400.54"];
				}
				else
				{
					// echo 1;
					//////////////////////////////////////////
					
					$partner_id = filter_var(trim($_REQUEST["partner_id"]), FILTER_SANITIZE_NUMBER_INT);
					$a = fopen("ug.txt","w");
	
					foreach($_REQUEST as $k=>$v)
					{
						if(is_array($v))
						{
							foreach($v as $kk=>$vv)
							{
								if(is_array($vv))
								{
									foreach($vv as $kkk=>$vvv)
									{
										fwrite($a,$k."===".$kk."===".$kkk."==".$vvv."\n");
									}
								}
								else
								{
									fwrite($a,$k."===".$kk."==".$vv."\n");
								}
							}
						}
						else
						{
							fwrite($a,$k."==".$v."\n");
						}

					}
					
					//$sql_raw = "SELECT SQL_CALC_FOUND_ROWS um.user_id, um.filter_name, um.user_type_id, um.role_id, um.status, um.updated_by, um.created_at, um.created_by, um.updated_at, pum.partner_user_id, pum.partner_id FROM user_master um LEFT JOIN partner_user_mapping pum ON um.user_id =pum.user_id WHERE pum.partner_id='".$partner_id."' ORDER BY pum.partner_user_id DESC LIMIT ".$offset.",".$newLimit;
					
					
					
					
					
					$aColumns = array('pfm.partner_filter_id', 'pfm.partner_com_id', 'pfm.filter_name','pfm.filter_data_type', 'pfm.status', 'pfm.field_value_sequence', 'pfm.updated_by', 'pfm.created_at', 'pfm.created_by', 'pfm.updated_at', 'apm.partner_name',);
					$sIndexColumn = "pfm.partner_filter_id";
					$sTable = "auro_partner_master apm , partner_filter_master pfm";
					$start=$_REQUEST['start'];
					fwrite($a,$sTable."\n");
					$sLimit = "";
					if ( isset( $_REQUEST['start'] ) && $_REQUEST['length'] != '-1' )
					{
						$sLimit = "LIMIT ".(int)$_REQUEST['start'].", ".(int)$_REQUEST['length'];
					}
					$orderbycol = empty($_REQUEST['order'][0]['column']) ? '' : $_REQUEST['order'][0]['column'];
					$orderby = empty($aColumns[$orderbycol]) ? 'pfm.partner_filter_id' : $aColumns[$orderbycol];
					$orderdir = empty($_REQUEST['order'][0]['dir']) ? 'desc' : $_REQUEST['order'][0]['dir'] ;

					fwrite($a,$orderdir."\n");
					fwrite($a,"OBY  ".$orderby."\n");
					
					$sWhere = " WHERE apm.partner_id = pfm.partner_com_id and pfm.partner_com_id='".$partner_id."' ";

					if ( $_REQUEST['search']['value']!= "" )
					{
						if($_REQUEST['search']['value']=='Active')
						{
							$searchval = "No";
						}
						else if($_REQUEST['search']['value']=='Inactive')
						{
							$searchval = "Yes";
						}
						else
						{
							$searchval = $_REQUEST['search']['value'];
						}
						$sWhere .= " WHERE  (";
						
						for ( $i=0 ; $i<count($aColumns) ; $i++ )
						{
							$sWhere .= $aColumns[$i]." LIKE '%".mysqli_real_escape_string($con, $searchval )."%' OR ";
						}
						$sWhere = substr_replace( $sWhere, "", -3 );
						$sWhere .= ')';
					}
					fwrite($a,$sWhere."\n");
					fwrite($a,"========================================================================\n");
					
					$sQuery = "
						SELECT SQL_CALC_FOUND_ROWS ".str_replace(" , ", " ", implode(", ", $aColumns))."
						FROM   $sTable
						$sWhere
						order by $orderby $orderdir 
						 $sLimit 
					";

					// echo $sQuery;
					// die ;
					//exit();


					fwrite($a,$sQuery."\n");
					fwrite($a,"========================================================================\n");
					$rResult = mysqli_query($con, $sQuery ) or die(mysqli_error());
					
					

					
					/* Data set length after filtering */
					$sQuery = "SELECT FOUND_ROWS()";
					fwrite($a,$sQuery."\n");
					fwrite($a,"========================================================================\n");
					
					$rResultFilterTotal = mysqli_query($con, $sQuery ) or die(mysqli_error());
					$aResultFilterTotal = mysqli_fetch_array($rResultFilterTotal);
					$iFilteredTotal = $aResultFilterTotal[0];
					
					/* Total data set length */
					$sQuery = "
						SELECT COUNT(".$sIndexColumn.")
						FROM   $sTable $sWhere";
					
					//die;	
					fwrite($a,$sQuery."\n");
					fwrite($a,"========================================================================\n");

					$rResultTotal = mysqli_query( $con, $sQuery ) or die(mysqli_error());
					$aResultTotal = mysqli_fetch_array($rResultTotal);
					$iTotal = $aResultTotal[0];
					
					/*
					 * Output
					 */
					 
					$return = array(
						"sEcho" => intval($_REQUEST['sEcho']),
						"iTotalRecords" => $iTotal,
						"iTotalDisplayRecords" => $iFilteredTotal,
						"status"=>"success",
						"error"=>"false",
						"response_code"=>200,
						"message"=>$AuroLangConvert["200.12"],
						"aaData" => array()
					);
					$sl_no =$start+1;

					$xx = 0;
					while ( $aRow = mysqli_fetch_array( $rResult ) )
					{
						$returndata = array();	
						
						//$aColumns = array('pfm.partner_filter_id', 'pfm.partner_com_id', 'pfm.filter_name','pfm.filter_data_type', 'pfm.status', 'pfm.field_value_sequence', 'pfm.updated_by', 'pfm.created_at', 'pfm.created_by', 'pfm.updated_at', 'apm.partner_name',);

					    $partner_filter_id = stripslashes($aRow["partner_filter_id"]);
					    $partner_com_id = stripslashes($aRow["partner_com_id"]);
					    $filter_name = stripslashes($aRow["filter_name"]);
					    $filter_type = stripslashes($aRow["filter_data_type"]);
					    $status = stripslashes($aRow["status"]);
					    $filed_value_sequence = stripslashes($aRow["field_value_sequence"]);
						$created_by =stripslashes($aRow["created_by"]);
						$updated_by=stripslashes($aRow["updated_by"]);
						$partner_name = stripslashes($aRow["partner_name"]);
						
						
						
						
						//$output['aaData'][] = $row;
						$aaa = "abccc";
						
						$returndata[]=$sl_no;
						$returndata[]=$partner_filter_id;
						$returndata[]=$partner_com_id;
						$returndata[]=$filter_name;
						$returndata[]=$filter_data_type;
						$returndata[]=$status;
						$returndata[]=$filed_value_sequence;
						$returndata[]=$created_by;
						$returndata[]=$updated_by;
						$returndata[]=$partner_name;
						$returndata[]='<a href='.$aaa.'>View</a>';
						
						$return['aaData'][] = $returndata;
						$sl_no++;
				    }
					fclose($a);	
					
				}
		}
	}
	else
	{
		$return["status"]="fail";
		$return["error"]="true";
		$return["response_code"] = 403;	
		$return["message"] = $AuroLangConvert["403.1"];
	}
}
else
{
	$return["status"]="fail";
	$return["error"]="true";
	$return["response_code"] = 403;	
	$return["message"] = $AuroLangConvert["403.1"];	
}
echo json_encode($return,JSON_UNESCAPED_UNICODE);
?>