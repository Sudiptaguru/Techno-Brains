<?php
//db functions
//$baseurl="http://localhost/tauro/";
$baseurl="https://staging.auroscholar.org/";

function wds_sanitize_string($string) {
	$string = str_replace(' +', ' ', trim($string));
	return preg_replace("/[<>]/", '_', $string);
}

function wdi($string) {
	global $con;
	if (function_exists('mysqli_real_escape_string')) {
	  return mysqli_real_escape_string($con,$string);
	} elseif (function_exists('mysqli_real_escape_string')) {
	  return mysqli_real_escape_string($con,$string);
	}
	return addslashes($string);
}

function wdpi($string) {
	if (is_string($string)) {
	  return trim(wds_sanitize_string($string));
	} elseif (is_array($string)) {
	  reset($string);
	  while (list($key, $value) = each($string)) {
		$string[$key] = wdpi($value);
	  }
	  return $string;
	} else {
	  return $string;
	}
}
    
function wfi($string){
	global $con;
	return trim(mysqli_real_escape_string($con,$_REQUEST[$string]));
}

function sl($string){
	return stripslashes(trim($string));
}

function check_eachchr($name){
	$ret = array();
	$len = strlen(trim($name));
	for ($z=0;$z<$len;$z++){
		array_push($ret,substr($name,$z,1));
	}
	return $ret;
}
  
function alpha_ar(){
	return array("a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","'","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"," ");
}

function user_ar(){
	return array("a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","0","1","2","3","4","5","6","7","8","9");
}

function num_ar(){
	return array("0","1","2","3","4","5","6","7","8","9");
}

function check_num($name){
	$name = stripslashes($name);
	$libar = num_ar();
	$argar = check_eachchr($name);
	$e ="";
	foreach ($argar as $k=>$v){
		if (!in_array($v,$libar)){
			$e = $e."1";
		}
	}
	if ($e==""){
		return true;
	}
	else{
		return false;
	}
}

function check_name($name){
	$name = stripslashes($name);
	$libar = alpha_ar();
	$argar = check_eachchr($name);
	$e ="";
	foreach ($argar as $k=>$v){
		if (!in_array($v,$libar)){
			$e = $e."1";
		}
	}
	if ($e==""){
		return true;
	}
	else{
		return false;
	}
}

function check_username($name){
	$name = stripslashes($name);
	$libar = user_ar();
	$argar = check_eachchr($name);
	$e ="";
	foreach ($argar as $k=>$v){
		if (!in_array($v,$libar)){
			$e = $e."1";
		}
	}
	if ($e==""){
		return true;
	}
	else{
		return false;
	}
}

function randomPassword() {
    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890�!$%^*';
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 10; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}

function CheckPasswordStrength($password){    
    $strength = 0;
    $patterns = array('#[a-z]#','#[A-Z]#','#[0-9]#','/[�!"�$%^&*()`{}\[\]:@~;\'#<>?,.\/\\-=_+\|]/');
    foreach($patterns as $pattern){
        if(preg_match($pattern,$password,$matches)){
            $strength++;
        }
    }
    return $strength;    
    // 1 - weak    // 2 - not weak    // 3 - acceptable    // 4 - strong
}

function checkEmail($email){
	$result = TRUE;
	if(!preg_match("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$", $email)){
		$result = FALSE;
	}
	return $result;
}

function validate_email($email){
	$exp = "^[a-z\'0-9]+([._-][a-z\'0-9]+)*@([a-z0-9]+([._-][a-z0-9]+))+$";
	if(preg_match($exp,$email)){
		return true;
	}else{
		return false;
	}   
}

function SentenceCase($str) {
	$str = strtolower($str);
    $sentences = explode(" ",$str);
    for($i=0;$i<count($sentences);$i++) {
        $sentences[$i][0] = ucfirst($sentences[$i][0]);
    }
    return implode(" ",$sentences);
}


function stripjavascript($string){
	$search = array ("'<script[^>]*?>.*?</script>'si");
	$replace = array ("");
	$string = preg_replace($search, $replace, $string);
	return $string;
}

function createthumb($name,$filename,$new_w,$new_h){
	$system=explode(".",$name);
	$cnn = count($system)-1;
	if (preg_match("/jpg|jpeg/",$system[$cnn])){$src_img=imagecreatefromjpeg($name);}
	if (preg_match("/png/",$system[$cnn])){$src_img=imagecreatefrompng($name);}
	if (preg_match("/gif/",$system[$cnn])){$src_img=imagecreatefromgif($name);}
	$old_x=imageSX($src_img);
	$old_y=imageSY($src_img);
	if ($old_x > $old_y){
		$thumb_w=$new_w;
		$thumb_h=$old_y*($new_h/$old_x);
	}
	if ($old_x < $old_y){
		$thumb_w=$old_x*($new_w/$old_y);
		$thumb_h=$new_h;
	}
	if ($old_x == $old_y){
		$thumb_w=$new_w;
		$thumb_h=$new_h;
	}
	$dst_img=ImageCreateTrueColor($thumb_w,$thumb_h);
	imagecopyresampled($dst_img,$src_img,0,0,0,0,$thumb_w,$thumb_h,$old_x,$old_y); 
	if (preg_match("/png/",$system[$cnn])){
		imagepng($dst_img,$filename); 
	} elseif (preg_match("/jpg|jpeg/",$system[$cnn])) {
		imagejpeg($dst_img,$filename); 
	}
	else{
		imagegif($dst_img,$filename); 
	}
	imagedestroy($dst_img); 
	imagedestroy($src_img); 
}
	
function rn_sqli_qry($sql){	
	global $con;
	mysqli_query($con,$sql) or die("all:".mysql_error());
}

function countryisdcode($cname){
	$countryisd=countryisdcodearray();
	if(isset($countryisd[$cname])){
		$code = $countryisd[$cname];
	}
	else{
		$code="";
	}
	return $code;
}

function countryisdcodearray(){
	$countryisd=array();
	$countryisd['United Kingdom']='+44';
	$countryisd['Argentina']='+54';
	$countryisd['Australia']='+61';
	$countryisd['Austria']='+43';
	$countryisd['Belgium']='+32';
	$countryisd['Bosnia']='+387';
	$countryisd['Canada']='+1';
	$countryisd['Chile']='+56';
	$countryisd['China']='+86';
	$countryisd['Croatia']='+385';
	$countryisd['Cyprus']='+357';
	$countryisd['Czech Republic']='+420';
	$countryisd['Denmark']='+45';
	$countryisd['Finland']='+358';
	$countryisd['France']='+33';
	$countryisd['Germany']='+49';
	$countryisd['Gibraltar']='+350';
	$countryisd['Greece']='+30';
	$countryisd['Hong Kong']='+852';
	$countryisd['Hungary']='+36';
	$countryisd['Iceland']='+354';
	$countryisd['India']='+91';
	$countryisd['Indonesia']='+62';
	$countryisd['Ireland']='+353';
	$countryisd['Israel']='+972';
	$countryisd['Italy']='+39';
	$countryisd['Japan']='+81';
	$countryisd['Jordan']='+962';
	$countryisd['Luxembourg']='+352';
	$countryisd['Macedonia']='+389';
	$countryisd['Malaysia']='+60';
	$countryisd['Malta']='+356';
	$countryisd['Netherlands']='+31';
	$countryisd['New Zealand']='+64';
	$countryisd['Norway']='+47';
	$countryisd['Oman']='+968';
	$countryisd['Poland']='+48';
	$countryisd['Portugal']='+351';
	$countryisd['Russia']='+7';
	$countryisd['Saudi Arabia']='+966';
	$countryisd['Serbia']='+381';
	$countryisd['Singapore']='+65';
	$countryisd['Slovakia']='+421';
	$countryisd['Slovenia']='+386';
	$countryisd['South Africa']='+27';
	$countryisd['South Korea']='+82';
	$countryisd['Spain']='+34';
	$countryisd['Sri Lanka']='+94';
	$countryisd['Sweden']='+46';
	$countryisd['Switzerland']='+41';
	$countryisd['Taiwan']='+886';
	$countryisd['Turkey']='+90';
	$countryisd['United Arab Emirates']='+971';
	$countryisd['USA']='+1';

	return $countryisd;
}

function helper_array_column($input, $array_index_key = NULL , $array_value = NULL ) 
{
    $result = array();

    if(count($input) > 0)
    {
        foreach( $input as $key => $value )
        {
            if(is_array($value))
            {
                $result[is_null($array_index_key) ? $key : (string)(is_callable($array_index_key)?$array_index_key($value):$value[$array_index_key])] = is_null($array_value) ? $value : (is_callable($array_value)?$array_value($value,$key):$value[$array_value]);
            }
            else if(is_object($value))
            {
                $result[is_null($array_index_key) ? $key : (string)$value->$array_index_key] = is_null($array_value) ? $value : $value->$array_value;
            }
            else
            {
                $result[is_null($array_index_key) ? $key : (string)(is_callable($array_index_key)?$array_index_key($value,$key):$key)] = is_null($array_value) ? $value : (string)(is_callable($array_value)?$array_value($value,$key):$value);
            }    
        }
    }    
    
    return $result;
}

/*
  	@Description: To generate array_column functionality such as set as multiple key and it's respective value
  	@Author     : Rahul Arora
  	@Input      : array , index key and it's values
  	@Output     : array
  	@Date       : 12-02-2021
  	*/   
 	function helper_array_column_multiple_key($input, $array_index_key = NULL , $add_extra_key = FALSE ,  $array_value = NULL) 
  	{
    	$result = array();

    	$add_extra_key_string = "";

	    if($add_extra_key)
	    {
	    	$add_extra_key_string = "[]";
	    }

    	if(!empty($input) && count($input) > 0)
    	{
      		$key_string = (implode("",array_map(function($value)
      		{

	        	$data_string = '[(string)$value["'.$value.'"]]';
	        	return $data_string;

	      	},$array_index_key)).$add_extra_key_string);


	      	foreach( $input as $key => $value)
	      	{
	        	if(is_array($value) && $key_string)
	        	{
	          		$execution = '$result'.$key_string.' = is_null($array_value) ? $value : $value[$array_value];';
	          		eval($execution);
	        	}
	      	}
    	}    
    	return $result;
  	}

function getIPAddress() {  
    //whether ip is from the share internet  
     if(!empty($_SERVER['HTTP_CLIENT_IP'])) {  
                $ip = $_SERVER['HTTP_CLIENT_IP'];  
        }  
    //whether ip is from the proxy  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
     }  
	//whether ip is from the remote address  
    else{  
             $ip = $_SERVER['REMOTE_ADDR'];  
     }  
     return $ip;  
}


function CheckAuthentication($secretid, $secretkey, $ipaddress){	
	global $con;
	$stmt = $con->prepare("SELECT * FROM api_authentication where secretid='".$secretid."' and secretkey='".$secretkey."' and server_ip='".$ipaddress."'");
	$stmt->execute();
	$result = $stmt->get_result(); 
	if($result->num_rows === 1){
		return true;
	}
	else{
		return false;
	}
}

function CheckUserMobileNo($mobile_no, $user_id, $user_type_id){	
	global $con;
	$stmt = $con->prepare("SELECT * FROM user_master where user_name='".$mobile_no."' and user_type_id='".$user_type_id."' and user_id!='".$user_id."'");
	//echo "SELECT * FROM user_master where user_name='".$mobile_no."' and user_type_id='".$user_type_id."' and user_id!='".$user_id."'";
	$stmt->execute();
	$result = $stmt->get_result(); 
	if($result->num_rows === 1){
		return false;
	}
	else{
		return true;
	}
}

function check_image_type($file_name){
	$system=explode(".",$file_name);
	$cnn = count($system)-1;
	$type = '.'.strtolower($system[$cnn]);
	if($type==".jpg" || $type==".jpeg" || $type==".png" || $type==".gif" || $type==".pdf"){
		return $type;
	}
	else{
		return false;
	}
}

function clean_str($string) {
   $string = str_replace(' ', '_', $string);
   return preg_replace('/[^A-Za-z0-9\_]/', '', $string);
}

function moneyFormatIndia($num){
    $nums = explode(".",$num);
    if(count($nums)>2){
        return "0";
    }else{
    if(count($nums)==1){
        $nums[1]="00";
    }
    $num = $nums[0];
    $explrestunits = "" ;
    if(strlen($num)>3){
        $lastthree = substr($num, strlen($num)-3, strlen($num));
        $restunits = substr($num, 0, strlen($num)-3); 
        $restunits = (strlen($restunits)%2 == 1)?"0".$restunits:$restunits; 
        $expunit = str_split($restunits, 2);
        for($i=0; $i<sizeof($expunit); $i++){

            if($i==0)
            {
                $explrestunits .= (int)$expunit[$i].","; 
            }else{
                $explrestunits .= $expunit[$i].",";
            }
        }
        $thecash = $explrestunits.$lastthree;
    } else {
        $thecash = $num;
    }
    return $thecash.".".$nums[1]; 
    }
}


?>