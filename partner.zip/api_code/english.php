<?php
//Kohin
$AuroLangConvert["403.1"] = "Access restricted";

$AuroLangConvert["400.1"] = "Error : Missing Data in body, nothing to process";
$AuroLangConvert["400.2"] = "Error : Missing Data Password";
$AuroLangConvert["400.3"] = "Error : Missing Data User Name";
$AuroLangConvert["400.4"] = "Error : Missing Data Email Id";
$AuroLangConvert["400.5"] = "Error : Missing Data Student name";
$AuroLangConvert["400.6"] = "Error : Missing Data Teacher name";
$AuroLangConvert["400.7"] = "Error : Missing Data Donor name";
$AuroLangConvert["400.8"] = "Error : Missing Data student Id";
$AuroLangConvert["400.9"] = "Error : Missing Data Teacher Id";
$AuroLangConvert["400.10"] = "Error : Missing Data Donor Id";
$AuroLangConvert["400.11"] = "Error : No Record Found.";
$AuroLangConvert["400.12"] = "Invalid Data : Password should atleast 6 characters";
$AuroLangConvert["400.13"] = "Invalid Data : Invalid User Name";
$AuroLangConvert["400.14"] = "Invalid Data : Invalid Email Id";
$AuroLangConvert["400.15"] = "Invalid Data : Invalid Student name";
$AuroLangConvert["400.16"] = "Invalid Data : Invalid Teacher name";
$AuroLangConvert["400.17"] = "Invalid Data : Invalid Donor name";
$AuroLangConvert["400.18"] = "Invalid Data : Invalid student Id";
$AuroLangConvert["400.19"] = "Invalid Data : Invalid Teacher Id";
$AuroLangConvert["400.20"] = "Invalid Data : Invalid Donor Id";
$AuroLangConvert["400.21"] = "Error : Student Already Exist";
$AuroLangConvert["400.22"] = "Error : Teacher Already Exist";
$AuroLangConvert["400.23"] = "Error : Donor Already Exist";
$AuroLangConvert["400.24"] = "Error : This Mobile No. Already Exist";
$AuroLangConvert["400.25"] = "Error : This User Name Already Exist";
$AuroLangConvert["400.26"] = "Error : This Email Id Already Exist";
$AuroLangConvert["400.30"] = "Error : Mobile No. Already verified";
$AuroLangConvert["400.31"] = "Error : Email Id Already verified";
$AuroLangConvert["400.32"] = "Invalid Data : Invalid Mobile No.";
$AuroLangConvert["400.33"] = "Error : Already Booked";
$AuroLangConvert["400.34"] = "Error : Not Yet Booked";
$AuroLangConvert["400.35"] = "Invalid Data : Invalid Image type";
$AuroLangConvert["400.36"] = "Error : Invalid Credential";

$AuroLangConvert["500.1"] = "Error : Technical issue encountered, please try again after some time";

$AuroLangConvert["200.1"] = "Success : Registraion Successfully";
$AuroLangConvert["200.2"] = "Success : Login Successfully";
$AuroLangConvert["200.3"] = "Success : Update Successfully";
$AuroLangConvert["200.4"] = "Success : Profile Show Successfully";
$AuroLangConvert["200.5"] = "Success : KYC Upload Successfully";
$AuroLangConvert["200.10"] = "Success : Data Show Successfully";





//vikram
$AuroLangConvert["200.6"] = "Success : Stream Added Successfully";
$AuroLangConvert["200.7"] = "Success : Header Display Fetched Successfully";
$AuroLangConvert["200.8"] = "Success : Stream Fetched Successfully";
$AuroLangConvert["200.9"] = "Success : No Stream Found";

$AuroLangConvert["400.27"] = "Invalid Data : Invalid Stream Id";
$AuroLangConvert["400.28"] = "Error : Missing Data Stream Id";
$AuroLangConvert["400.29"] = "Error : No Stream Id found Associate with Donor Id";
?>