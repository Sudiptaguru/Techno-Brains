<?php
	error_reporting(1);
	//$con2 = new mysqli("localhost", "current_auro", "&11ce0lO", "current_auro");
	$con2 = new mysqli("localhost", "root", "", "cdb");
	if ($con2->connect_errno){
		printf("Connect failed: %s\n", $con2->connect_error);
		exit();
	}
?>