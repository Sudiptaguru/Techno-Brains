<?php
	error_reporting(1);
	//$con = new mysqli("localhost", "staging_user", "?xgD45t5", "staging_auroscholor_laravel");
	$con = new mysqli("localhost", "root", "", "tauro");
	if ($con->connect_errno){
		printf("Connect failed: %s\n", $con->connect_error);
		exit();
	}
?>