<?php
//********* [BASEURL]/api/partner/partner_update.php ********/

ob_start();
include("../db.php");
include("../functions.php");
$headers = apache_request_headers();
$return = array();
$return["status"] 	= "fail";
$return["error"] 	= "true";
$collection=array();
$server_ip=$_SERVER["SERVER_ADDR"];
$lang_code =  strtolower($headers["Lang-Code"]);
$allowedMethods = array('POST');
$requestMethod = strtoupper($_SERVER['REQUEST_METHOD']);
if(!in_array($requestMethod, $allowedMethods)){	
	http_response_code(405);
	$return["response_code"]=405;
	$return["message"]=$AuroLangConvert["405.1"];
	echo json_encode($return,JSON_UNESCAPED_UNICODE);
	exit;			
}
if($lang_code!=""){
	if(file_get_contents("../".$lang_code.".php")){
		include("../".$lang_code.".php");
	}
	else{
		include("../english.php");		
	}
}
else{
	include("../english.php");
}
if(isset($headers["Secret-Id"]) && isset($headers["Secret-Key"]) && isset($headers["Lang-Code"])){
	$secretid =  $headers["Secret-Id"];
	$secretkey =  $headers["Secret-Key"];
	
	if(CheckAuthentication($secretid, $secretkey, $server_ip)) {
		$json = file_get_contents('php://input');
		if(trim($json)=="") {
			$return["response_code"]	= 400;			
			$return["message"]			= $AuroLangConvert["400.1"];			
		}
		else {
			$data = json_decode($json,true);
			if(!empty($data)) {
				if (!isset($data["partner_name"]) || $data["partner_name"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.51"];
				}
				elseif (!isset($data["partner_id"]) || $data["partner_id"] == '' ){
					$return["response_code"]	= 400;	
					$return["message"]			= $AuroLangConvert["400.54"];
				}
				else {
					$partner_id 			= filter_var(trim($data["partner_id"]), FILTER_SANITIZE_NUMBER_INT);
					$partner_name 			= filter_var(trim($data["partner_name"]), FILTER_SANITIZE_STRING);
					$partner_source 		= filter_var(trim($data["partner_source"]), FILTER_SANITIZE_STRING);
					$registration_date 		= filter_var(trim($data["registration_date"]), FILTER_SANITIZE_STRING);
					$feature 				= filter_var(trim($data["feature"]), FILTER_SANITIZE_NUMBER_INT);
					$user_type_id 			= filter_var(trim($data["user_type_id"]), FILTER_SANITIZE_NUMBER_INT);
					$role_id 				= filter_var(trim($data["role_id"]), FILTER_SANITIZE_NUMBER_INT);
					$status 				= filter_var(trim($data["status"]), FILTER_SANITIZE_NUMBER_INT);
					$partner_logo 			= filter_var(trim($data["partner_logo"]), FILTER_SANITIZE_STRING);
					$partner_website 		= filter_var(trim($data["partner_website"]), FILTER_SANITIZE_STRING);
					$partner_internal_url 	= filter_var(trim($data["partner_internal_url"]), FILTER_SANITIZE_STRING);
					$required_params 		= filter_var(trim($data["required_params"]), FILTER_SANITIZE_STRING);
					$mobile_no_verified 	= filter_var(trim($data["mobile_no_verified"]), FILTER_SANITIZE_NUMBER_INT);
					$updated_by 			= filter_var(trim($data["updated_by"]), FILTER_SANITIZE_NUMBER_INT);
				
					$current_date = date('Y-m-d H:i:s');
					$stmt = $con->prepare("UPDATE auro_partner_master SET partner_name = '".$partner_name."', partner_source = '".$partner_source."', registration_date = '".$registration_date."', feature = '".$feature."', status = '".$status."', partner_logo = '".$partner_logo."', partner_website = '".$partner_website."', partner_internal_url = '".$partner_internal_url."', required_params = '".$required_params."', mobile_no_verified = '".$mobile_no_verified."', updated_by = '".$updated_by."', updated_at = '".$current_date."' WHERE partner_id=".$partner_id);
					$stmt->execute();
					if ($stmt->affected_rows > 0){
						$return["status"]					= "success";
						$return["error"]					= "false";
						$return["response_code"]			= 200;			
						$return["message"]					= $AuroLangConvert["200.3"];
						$return["data"]["partner_id"]		= (string)$partner_id;
					}
					$stmt->close();	
				}
			}
			else {
				$return["response_code"]	= 400;
				$return["message"]			= $AuroLangConvert["400.1"];
			}			
		}
	}
	else {
		$return["response_code"]	= 403;	
		$return["message"]			= $AuroLangConvert["403.1"];
	}
}
else{
	$return["response_code"]	= 403;	
	$return["message"]			= $AuroLangConvert["403.1"];	
}
echo json_encode($return,JSON_UNESCAPED_UNICODE);
?>