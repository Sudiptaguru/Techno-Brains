<?php
	error_reporting(1);
	//$con2 = new mysqli("localhost", "current_auro", "&11ce0lO", "current_auro");
	$con3 = new mysqli("localhost", "root", "", "tauro_old");
	if ($con3->connect_errno){
		printf("Connect failed: %s\n", $con3->connect_error);
		exit();
	}
?>