<?php
//********* [BASEURL]/partner/comm_vendor_insert.php ********/

ob_start();
include("../db.php");
include("../functions.php");
$headers = apache_request_headers();
$return = array();
$return["status"] 	= "fail";
$return["error"] 	= "true";
$collection=array();
$server_ip=$_SERVER["SERVER_ADDR"];
$lang_code =  strtolower($headers["Lang-Code"]);
if($lang_code!=""){
	if(file_get_contents("../".$lang_code.".php")){
		include("../".$lang_code.".php");
	}
	else{
		include("../english.php");		
	}
}
else{
	include("../english.php");
}
$allowedMethods = array('POST');
$requestMethod = strtoupper($_SERVER['REQUEST_METHOD']);
if(!in_array($requestMethod, $allowedMethods)){	
	http_response_code(405);
	$return["response_code"]=405;
	$return["message"]=$AuroLangConvert["405.1"];
	echo json_encode($return,JSON_UNESCAPED_UNICODE);
	exit;			
}
if(isset($headers["Secret-Id"]) && isset($headers["Secret-Key"]) && isset($headers["Lang-Code"])){
	$secretid =  $headers["Secret-Id"];
	$secretkey =  $headers["Secret-Key"];
	
	if(CheckAuthentication($secretid, $secretkey, $server_ip)) {
		$json = file_get_contents('php://input');
		if(trim($json)=="") {
			$return["response_code"]	= 4002;
			$return["message"]			= $AuroLangConvert["400.1"];			
		}
		else {
			$data = json_decode($json,true);
			if(!empty($data)) {
				if (!isset($data["sendered_text"]) || $data["sendered_text"] == '' ){
					$return["response_code"]	= 4003;			
					$return["message"]			= $AuroLangConvert["400.65"];
				}
				elseif (!isset($data["status"]) || $data["status"] == '' ){
					$return["response_code"]	= 4004;			
					$return["message"]			= $AuroLangConvert["400.66"];
				}
				else {
					$sendered_text 			= filter_var(trim($data["sendered_text"]), FILTER_SANITIZE_STRING);
					$com_vendor_id			= filter_var(trim($data["com_vendor_id"]), FILTER_SANITIZE_STRING);
					$com_type 	= filter_var(trim($data["com_type"]), FILTER_SANITIZE_STRING);
					$status 				= filter_var(trim($data["status"]), FILTER_SANITIZE_NUMBER_INT);
					$partner_id 			= filter_var(trim($data["partner_id"]), FILTER_SANITIZE_STRING);
					$created_by 			= filter_var(trim($data["created_by"]), FILTER_SANITIZE_NUMBER_INT);
					$updated_by 			= filter_var(trim($data["updated_by"]), FILTER_SANITIZE_NUMBER_INT);
					
					 {
						$current_date = date('Y-m-d H:i:s');

						$stmt = $con->prepare("INSERT INTO partner_com_sender_master (`sendered_text`, `com_vendor_id`, `com_type`, `status`, `partner_id`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES ('".$sendered_text."', '".$com_vendor_id."', '".$com_type."', '".$status."','".$partner_id."', '".$created_by."', '".$updated_by."', '".$current_date."','".$current_date."' )");
						$stmt->execute();
						$record_id = $stmt->insert_id;

						$return["status"]					= "success";
						$return["error"]					= "false";
						$return["response_code"]			= 200;			
						$return["message"]					= $AuroLangConvert["200.1"];
						$return["data"]["com_sender_id"]	= (string)$record_id;
					}
					$stmt->close();	
				}
			}
			else {
				$return["response_code"]	= 4005;
				$return["message"]			= $AuroLangConvert["400.1"];
			}			
		}
	}
	else {
		$return["response_code"]	= 403;	
		$return["message"]			= $AuroLangConvert["403.1"];
	}
}
else{
	$return["response_code"]	= 403;	
	$return["message"]			= $AuroLangConvert["403.1"];	
}
echo json_encode($return,JSON_UNESCAPED_UNICODE);
?>