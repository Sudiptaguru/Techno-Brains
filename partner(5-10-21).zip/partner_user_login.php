<?php
//********* [BASEURL]/partner/partner_user_login.php ********/

ob_start();
include("../db.php");
include("../functions.php");
$headers = apache_request_headers();
$return = array();
$return["status"] 	= "fail";
$return["error"] 	= "true";
$collection=array();
$server_ip=$_SERVER["SERVER_ADDR"];
$lang_code =  strtolower($headers["Lang-Code"]);
$allowedMethods = array('POST');
$requestMethod = strtoupper($_SERVER['REQUEST_METHOD']);
if(!in_array($requestMethod, $allowedMethods)){	
	http_response_code(405);
	$return["response_code"]=405;
	$return["message"]=$AuroLangConvert["405.1"];
	echo json_encode($return,JSON_UNESCAPED_UNICODE);
	exit;			
}
if($lang_code!=""){
	if(file_get_contents("../".$lang_code.".php")){
		include("../".$lang_code.".php");
	}
	else{
		include("../english.php");		
	}
}
else{
	include("../english.php");
}
if(isset($headers["Secret-Id"]) && isset($headers["Secret-Key"]) && isset($headers["Lang-Code"])){
	$secretid =  $headers["Secret-Id"];
	$secretkey =  $headers["Secret-Key"];
	
	if(CheckAuthentication($secretid, $secretkey, $server_ip)) {
		$json = file_get_contents('php://input');
		if(trim($json)=="") {
			$return["response_code"]	= 400;			
			$return["message"]			= $AuroLangConvert["400.1"];			
		}
		else {
			$data = json_decode($json,true);
			if(!empty($data)) {
				if (!isset($data["user_name"]) || $data["user_name"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.3"];
				}
				elseif (!isset($data["password"]) || $data["password"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.2"];
				}
				elseif (!isset($data["user_type_id"]) || $data["user_type_id"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.53"];
				}
				else {
					$user_name 		= filter_var(trim($data["user_name"]), FILTER_SANITIZE_STRING);
					$password 		= filter_var(trim($data["password"]), FILTER_SANITIZE_STRING);
					$user_type_id 	= filter_var(trim($data["user_type_id"]), FILTER_SANITIZE_NUMBER_INT);

					$stmt = $con->prepare("SELECT * FROM user_master WHERE user_name='".$user_name."' AND password='".md5($password)."' AND user_type_id='".$user_type_id."'");
					$stmt->execute();
					$result = $stmt->get_result(); 
					if($result->num_rows === 0) {
						$return["response_code"]= 400;			
						$return["message"]=$AuroLangConvert["400.11"];
					}
					else {
						$row = $result->fetch_assoc();
						$return["status"]		= "success";
						$return["error"]		= "false";
						$return["response_code"]= 200;
						$return["message"]		= $AuroLangConvert["200.4"];
						$return["user_id"]		= (string)$row["user_id"];
					}
					$stmt->close();	
				}
			}
			else {
				$return["response_code"]	= 400;
				$return["message"]			= $AuroLangConvert["400.1"];
			}			
		}
	}
	else {
		$return["response_code"]	= 403;	
		$return["message"]			= $AuroLangConvert["403.1"];
	}
}
else{
	$return["response_code"]	= 403;	
	$return["message"]			= $AuroLangConvert["403.1"];	
}
echo json_encode($return,JSON_UNESCAPED_UNICODE);
?>