<?php
//********* [BASEURL]/partner/comm_vendor_view.php ********/

ob_start();
include("../db.php");
include("../functions.php");
$headers = apache_request_headers();
$return = array();
$return["status"] 	= "fail";
$return["error"] 	= "true";
$collection=array();
$server_ip=$_SERVER["SERVER_ADDR"];
$lang_code =  strtolower($headers["Lang-Code"]);
if($lang_code!=""){
	if(file_get_contents("../".$lang_code.".php")){
		include("../".$lang_code.".php");
	}
	else{
		include("../english.php");		
	}
}
else{
	include("../english.php");
}
$allowedMethods = array('POST');
$requestMethod = strtoupper($_SERVER['REQUEST_METHOD']);
if(!in_array($requestMethod, $allowedMethods)){	
	http_response_code(405);
	$return["response_code"]=405;
	$return["message"]=$AuroLangConvert["405.1"];
	echo json_encode($return,JSON_UNESCAPED_UNICODE);
	exit;			
}
if(isset($headers["Secret-Id"]) && isset($headers["Secret-Key"]) && isset($headers["Lang-Code"])){
	$secretid =  $headers["Secret-Id"];
	$secretkey =  $headers["Secret-Key"];
	
	if(CheckAuthentication($secretid, $secretkey, $server_ip)) {
		$json = file_get_contents('php://input');
		if(trim($json)=="") {
			$return["response_code"]	= 400;			
			$return["message"]			= $AuroLangConvert["400.1"];			
		}
		else {
			$data = json_decode($json,true);
			if(!empty($data)) {
				if (!isset($data["com_sender_id"]) || $data["com_sender_id"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.67"];
				}
				else {
					$com_sender_id 	= filter_var(trim($data["com_sender_id"]), FILTER_SANITIZE_NUMBER_INT);
					$stmt = $con->prepare("SELECT partner_com_sender_master.com_sender_id, partner_com_sender_master.sendered_text, partner_com_sender_master.com_vendor_id, com_vendor_master.vendor_name, partner_com_sender_master.com_type, partner_com_sender_master.status, partner_com_sender_master.partner_id, auro_partner_master.partner_name, partner_com_sender_master.created_by, partner_com_sender_master.updated_by FROM partner_com_sender_master LEFT join com_vendor_master ON com_vendor_master.com_vendor_id=partner_com_sender_master.com_vendor_id LEFT join auro_partner_master ON partner_com_sender_master.partner_id=auro_partner_master.partner_id where partner_com_sender_master.com_sender_id='".$com_sender_id."'");

					

					$stmt->execute();
					$result = $stmt->get_result(); 
					if($result->num_rows === 0) {
						$return["response_code"]= 400;			
						$return["message"]=$AuroLangConvert["400.11"];
					}
					else {
						$row = $result->fetch_assoc();
						$return["status"]		= "success";
						$return["error"]		= "false";
						$return["response_code"]= 200;
						$return["message"]		= $AuroLangConvert["200.4"];
						$r = [];
						foreach($row as $key => $val) {
							$r[$key] = (string)$val;
						}
						$return["data"] = $r;
					}
					$stmt->close();	
				}
			}
			else {
				$return["response_code"]	= 400;
				$return["message"]			= $AuroLangConvert["400.1"];
			}			
		}
	}
	else {
		$return["response_code"]	= 403;	
		$return["message"]			= $AuroLangConvert["403.1"];
	}
}
else{
	$return["response_code"]	= 403;	
	$return["message"]			= $AuroLangConvert["403.1"];	
}
echo json_encode($return,JSON_UNESCAPED_UNICODE);
?>