<?php
//********* [BASEURL]/partner/comm_tmpl_insert.php ********/

ob_start();
include("../db.php");
include("../functions.php");
$headers = apache_request_headers();
$return = array();
$return["status"] 	= "fail";
$return["error"] 	= "true";
$collection=array();
$server_ip=$_SERVER["SERVER_ADDR"];
$lang_code =  strtolower($headers["Lang-Code"]);
if($lang_code!=""){
	if(file_get_contents("../".$lang_code.".php")){
		include("../".$lang_code.".php");
	}
	else{
		include("../english.php");		
	}
}
else{
	include("../english.php");
}
$allowedMethods = array('POST');
$requestMethod = strtoupper($_SERVER['REQUEST_METHOD']);
if(!in_array($requestMethod, $allowedMethods)){	
	http_response_code(405);
	$return["response_code"]=405;
	$return["message"]=$AuroLangConvert["405.1"];
	echo json_encode($return,JSON_UNESCAPED_UNICODE);
	exit;			
}
if(isset($headers["Secret-Id"]) && isset($headers["Secret-Key"]) && isset($headers["Lang-Code"])){
	$secretid =  $headers["Secret-Id"];
	$secretkey =  $headers["Secret-Key"];
	
	if(CheckAuthentication($secretid, $secretkey, $server_ip)) {
		$json = file_get_contents('php://input');
		if(trim($json)=="") {
			$return["response_code"]	= 400;			
			$return["message"]			= $AuroLangConvert["400.1"];			
		}
		else {
			$data = json_decode($json,true);
			if(!empty($data)) {
				if (!isset($data["partner_id"]) || $data["partner_id"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.54"];
				}
				elseif (!isset($data["template_name"]) || $data["template_name"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.61"];
				}
				elseif (!isset($data["com_type"]) || $data["com_type"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.62"];
				}
				elseif (!isset($data["template_text"]) || $data["template_text"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.63"];
				}
				else {
					$template_name 	= filter_var(trim($data["template_name"]), FILTER_SANITIZE_STRING);
					$com_type		= filter_var(trim($data["com_type"]), FILTER_SANITIZE_STRING);
					$template_text 	= filter_var(trim($data["template_text"]), FILTER_SANITIZE_STRING);
					$status 		= filter_var(trim($data["status"]), FILTER_SANITIZE_NUMBER_INT);
					$partner_id 	= filter_var(trim($data["partner_id"]), FILTER_SANITIZE_NUMBER_INT);
					$created_by 	= filter_var(trim($data["created_by"]), FILTER_SANITIZE_NUMBER_INT);
					$updated_by 	= filter_var(trim($data["updated_by"]), FILTER_SANITIZE_NUMBER_INT);
					
					$stmt = $con->prepare("SELECT * FROM com_template_master WHERE partner_id=".$partner_id." AND template_name LIKE '".$template_name."'");
					$stmt->execute();
					$result = $stmt->get_result();
					if($result->num_rows > 0) {
						$return["response_code"]	= 400;	
						$return["message"]			= $AuroLangConvert["400.38"];
					}
					else {
						$current_date = date('Y-m-d H:i:s');

						$stmt = $con->prepare("INSERT INTO com_template_master (`template_name`, `com_type`, `template_text`, `status`, `partner_id`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES ('".$template_name."', '".$com_type."', '".$template_text."', '".$status."', '".$partner_id."', '".$created_by."', '".$updated_by."', '".$current_date."','".$current_date."' )");
						$stmt->execute();
						$record_id = $stmt->insert_id;

						$return["status"]					= "success";
						$return["error"]					= "false";
						$return["response_code"]			= 200;			
						$return["message"]					= $AuroLangConvert["200.1"];
						$return["data"]["com_template_id"]	= (string)$record_id;
						$return["data"]["partner_id"]		= (string)$partner_id;
					}
					$stmt->close();	
				}
			}
			else {
				$return["response_code"]	= 400;
				$return["message"]			= $AuroLangConvert["400.1"];
			}			
		}
	}
	else {
		$return["response_code"]	= 403;	
		$return["message"]			= $AuroLangConvert["403.1"];
	}
}
else{
	$return["response_code"]	= 403;	
	$return["message"]			= $AuroLangConvert["403.1"];	
}
echo json_encode($return,JSON_UNESCAPED_UNICODE);
?>