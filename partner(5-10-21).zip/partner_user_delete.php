<?php
//********* [BASEURL]partner/partner_user_delete.php ********/

ob_start();
include("../db.php");
include("../functions.php");
$headers = apache_request_headers();
$return = array();
$return["status"] 	= "fail";
$return["error"] 	= "true";
$collection=array();
$server_ip=$_SERVER["SERVER_ADDR"];
$lang_code =  strtolower($headers["Lang-Code"]);
$allowedMethods = array('POST');
$requestMethod = strtoupper($_SERVER['REQUEST_METHOD']);
if(!in_array($requestMethod, $allowedMethods)){	
	http_response_code(405);
	$return["response_code"]=405;
	$return["message"]=$AuroLangConvert["405.1"];
	echo json_encode($return,JSON_UNESCAPED_UNICODE);
	exit;			
}
if($lang_code!=""){
	if(file_get_contents("../".$lang_code.".php")){
		include("../".$lang_code.".php");
	}
	else{
		include("../english.php");		
	}
}
else{
	include("../english.php");
}
if(isset($headers["Secret-Id"]) && isset($headers["Secret-Key"]) && isset($headers["Lang-Code"])){
	$secretid =  $headers["Secret-Id"];
	$secretkey =  $headers["Secret-Key"];
	
	if(CheckAuthentication($secretid, $secretkey, $server_ip)) {
		$json = file_get_contents('php://input');
		if(trim($json)=="") {
			$return["response_code"]	= 400;			
			$return["message"]			= $AuroLangConvert["400.1"];			
		}
		else {
			$data = json_decode($json,true);
			if(!empty($data)) {
				if (!isset($data["partner_user_id"]) || $data["partner_user_id"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.58"];
				}
				else {
					$partner_user_id 	= filter_var(trim($data["partner_user_id"]), FILTER_SANITIZE_NUMBER_INT);
					
					$stmtp = $con->prepare("SELECT partner_id FROM partner_user_mapping where partner_user_id='".$partner_user_id."'");				
					$stmtp->execute();
					$resultp = $stmtp->get_result();
					$rowp 	= $resultp->fetch_assoc();
					$partner_id=$rowp['partner_id'];
					
					$stmt = $con->prepare("DELETE pum,um FROM partner_user_mapping pum LEFT JOIN user_master um ON um.user_id =pum.user_id WHERE pum.partner_user_id=".$partner_user_id);
					$stmt->execute();
					if ($stmt->affected_rows > 0){
						$return["status"]		= "success";
						$return["error"]		= "false";
						$return["response_code"]= 200;
						$return["message"]		= $AuroLangConvert["200.3"];
						$return["data"]["partner_id"]	= (string)$partner_id;
						$return["data"]["partner_user_id"]	= (string)$partner_user_id;
					}
					else{
						$return["response_code"]= 400;			
						$return["message"]=$AuroLangConvert["400.57"];
					}
					$stmt->close();	
				}
			}
			else {
				$return["response_code"]	= 400;
				$return["message"]			= $AuroLangConvert["400.1"];
			}			
		}
	}
	else {
		$return["response_code"]	= 403;	
		$return["message"]			= $AuroLangConvert["403.1"];
	}
}
else{
	$return["response_code"]	= 403;	
	$return["message"]			= $AuroLangConvert["403.1"];	
}
echo json_encode($return,JSON_UNESCAPED_UNICODE);
?>