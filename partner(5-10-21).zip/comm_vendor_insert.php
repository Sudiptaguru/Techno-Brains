<?php
//********* [BASEURL]/partner/comm_vendor_insert.php ********/

ob_start();
include("../db.php");
include("../functions.php");
$headers = apache_request_headers();
$return = array();
$return["status"] 	= "fail";
$return["error"] 	= "true";
$collection=array();
$server_ip=$_SERVER["SERVER_ADDR"];
$lang_code =  strtolower($headers["Lang-Code"]);
if($lang_code!=""){
	if(file_get_contents("../".$lang_code.".php")){
		include("../".$lang_code.".php");
	}
	else{
		include("../english.php");		
	}
}
else{
	include("../english.php");
}
$allowedMethods = array('POST');
$requestMethod = strtoupper($_SERVER['REQUEST_METHOD']);
if(!in_array($requestMethod, $allowedMethods)){	
	http_response_code(405);
	$return["response_code"]=405;
	$return["message"]=$AuroLangConvert["405.1"];
	echo json_encode($return,JSON_UNESCAPED_UNICODE);
	exit;			
}
if(isset($headers["Secret-Id"]) && isset($headers["Secret-Key"]) && isset($headers["Lang-Code"])){
	$secretid =  $headers["Secret-Id"];
	$secretkey =  $headers["Secret-Key"];
	
	if(CheckAuthentication($secretid, $secretkey, $server_ip)) {
		$json = file_get_contents('php://input');
		if(trim($json)=="") {
			$return["response_code"]	= 400;
			$return["message"]			= $AuroLangConvert["400.1"];			
		}
		else {
			$data = json_decode($json,true);
			if(!empty($data)) {
				if (!isset($data["vendor_name"]) || $data["vendor_name"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.65"];
				}
				elseif (!isset($data["status"]) || $data["status"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.66"];
				}
				else {
					$vendor_name 			= filter_var(trim($data["vendor_name"]), FILTER_SANITIZE_STRING);
					$service_name			= filter_var(trim($data["service_name"]), FILTER_SANITIZE_STRING);
					$vendor_contact_name 	= filter_var(trim($data["vendor_contact_name"]), FILTER_SANITIZE_STRING);
					$vendor_contact_no 		= filter_var(trim($data["vendor_contact_no"]), FILTER_SANITIZE_STRING);
					$vendor_contact_email 	= filter_var(trim($data["vendor_contact_email"]), FILTER_SANITIZE_STRING);
					$status 				= filter_var(trim($data["status"]), FILTER_SANITIZE_NUMBER_INT);
					$vendor_remark 			= filter_var(trim($data["vendor_remark"]), FILTER_SANITIZE_STRING);
					$created_by 			= filter_var(trim($data["created_by"]), FILTER_SANITIZE_NUMBER_INT);
					$updated_by 			= filter_var(trim($data["updated_by"]), FILTER_SANITIZE_NUMBER_INT);
					
					$stmt = $con->prepare("SELECT * FROM com_vendor_master WHERE vendor_name LIKE '".$vendor_name."'");
					$stmt->execute();
					$result = $stmt->get_result();
					if($result->num_rows > 0) {
						$return["response_code"]	= 400;	
						$return["message"]			= $AuroLangConvert["400.38"];
					}
					else {
						$current_date = date('Y-m-d H:i:s');

						$stmt = $con->prepare("INSERT INTO com_vendor_master (`vendor_name`, `service_name`, `vendor_contact_name`, `vendor_contact_no`, `vendor_contact_email`, `status`, `vendor_remark`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES ('".$vendor_name."', '".$service_name."', '".$vendor_contact_name."', '".$vendor_contact_no."', '".$vendor_contact_email."','".$status."','".$vendor_remark."', '".$created_by."', '".$updated_by."', '".$current_date."','".$current_date."' )");
						$stmt->execute();
						$record_id = $stmt->insert_id;

						$return["status"]					= "success";
						$return["error"]					= "false";
						$return["response_code"]			= 200;			
						$return["message"]					= $AuroLangConvert["200.1"];
						$return["data"]["com_vendor_id"]	= (string)$record_id;
					}
					$stmt->close();	
				}
			}
			else {
				$return["response_code"]	= 400;
				$return["message"]			= $AuroLangConvert["400.1"];
			}			
		}
	}
	else {
		$return["response_code"]	= 403;	
		$return["message"]			= $AuroLangConvert["403.1"];
	}
}
else{
	$return["response_code"]	= 403;	
	$return["message"]			= $AuroLangConvert["403.1"];	
}
echo json_encode($return,JSON_UNESCAPED_UNICODE);
?>