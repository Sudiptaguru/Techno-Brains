<?php
//********* [BASEURL]/partner/partner_comm_insert.php ********/

ob_start();
include("../db.php");
include("../functions.php");
$headers = apache_request_headers();
$return = array();
$return["status"] 	= "fail";
$return["error"] 	= "true";
$collection=array();
$server_ip=$_SERVER["SERVER_ADDR"];
$lang_code =  strtolower($headers["Lang-Code"]);
$allowedMethods = array('POST');
$requestMethod = strtoupper($_SERVER['REQUEST_METHOD']);
if(!in_array($requestMethod, $allowedMethods)){	
	http_response_code(405);
	$return["response_code"]=405;
	$return["message"]=$AuroLangConvert["405.1"];
	echo json_encode($return,JSON_UNESCAPED_UNICODE);
	exit;			
}
if($lang_code!=""){
	if(file_get_contents("../".$lang_code.".php")){
		include("../".$lang_code.".php");
	}
	else{
		include("../english.php");		
	}
}
else{
	include("../english.php");
}
if(isset($headers["Secret-Id"]) && isset($headers["Secret-Key"]) && isset($headers["Lang-Code"])){
	$secretid =  $headers["Secret-Id"];
	$secretkey =  $headers["Secret-Key"];
	
	if(CheckAuthentication($secretid, $secretkey, $server_ip)) {
		$json = file_get_contents('php://input');
		if(trim($json)=="") {
			$return["response_code"]	= 400;			
			$return["message"]			= $AuroLangConvert["400.1"];			
		}
		else {
			$data = json_decode($json,true);
			if(!empty($data)) {
				if (!isset($data["partner_id"]) || $data["partner_id"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.54"];
				}
				elseif (!isset($data["partner_name"]) || $data["partner_name"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.59"];
				}
				else {
					$partner_name 			= filter_var(trim($data["partner_name"]), FILTER_SANITIZE_STRING);
					$partner_logo			= filter_var(trim($data["partner_logo"]), FILTER_SANITIZE_STRING);
					$partner_description 	= filter_var(trim($data["partner_description"]), FILTER_SANITIZE_STRING);
					$partner_id 			= filter_var(trim($data["partner_id"]), FILTER_SANITIZE_NUMBER_INT);
					$status 				= filter_var(trim($data["status"]), FILTER_SANITIZE_NUMBER_INT);
					$created_by 			= filter_var(trim($data["created_by"]), FILTER_SANITIZE_NUMBER_INT);
					$updated_by 			= filter_var(trim($data["updated_by"]), FILTER_SANITIZE_NUMBER_INT);
					
					$stmt = $con->prepare("SELECT * FROM partner_com_master where partner_id=".$partner_id." AND partner_name='".$partner_name."'");
					$stmt->execute();
					$result = $stmt->get_result();
					if($result->num_rows > 0) {
						$return["response_code"]	= 400;	
						$return["message"]			= $AuroLangConvert["400.38"];
					}
					else {
						$current_date = date('Y-m-d H:i:s');

						$stmt = $con->prepare("INSERT INTO partner_com_master (`partner_name`, `partner_logo`, `partner_description`, `partner_id`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES ('".$partner_name."', '".$partner_logo."', '".$partner_description."', '".$partner_id."', '".$status."', '".$created_by."', '".$updated_by."', '".$current_date."','".$current_date."' )");
						$stmt->execute();
						$partner_com_id = $stmt->insert_id;

						$return["status"]					= "success";
						$return["error"]					= "false";
						$return["response_code"]			= 200;			
						$return["message"]					= $AuroLangConvert["200.1"];
						$return["data"]["partner_com_id"]	= (string)$partner_com_id;
						$return["data"]["partner_id"]		= (string)$partner_id;
					}
					$stmt->close();	
				}
			}
			else {
				$return["response_code"]	= 400;
				$return["message"]			= $AuroLangConvert["400.1"];
			}			
		}
	}
	else {
		$return["response_code"]	= 403;	
		$return["message"]			= $AuroLangConvert["403.1"];
	}
}
else{
	$return["response_code"]	= 403;	
	$return["message"]			= $AuroLangConvert["403.1"];	
}
echo json_encode($return,JSON_UNESCAPED_UNICODE);
?>