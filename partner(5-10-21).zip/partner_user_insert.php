<?php
//********* [BASEURL]/apis/partner/partner_user_insert.php ********/

ob_start();
include("../db.php");
include("../functions.php");
$headers = apache_request_headers();
$return = array();
$return["status"] 	= "fail";
$return["error"] 	= "true";
$collection=array();
$server_ip=$_SERVER["SERVER_ADDR"];
$lang_code =  strtolower($headers["Lang-Code"]);
$allowedMethods = array('POST');
$requestMethod = strtoupper($_SERVER['REQUEST_METHOD']);
if(!in_array($requestMethod, $allowedMethods)){	
	http_response_code(405);
	$return["response_code"]=405;
	$return["message"]=$AuroLangConvert["405.1"];
	echo json_encode($return,JSON_UNESCAPED_UNICODE);
	exit;			
}
if($lang_code!=""){
	if(file_get_contents("../".$lang_code.".php")){
		include("../".$lang_code.".php");
	}
	else{
		include("../english.php");		
	}
}
else{
	include("../english.php");
}
if(isset($headers["Secret-Id"]) && isset($headers["Secret-Key"]) && isset($headers["Lang-Code"])){
	$secretid =  $headers["Secret-Id"];
	$secretkey =  $headers["Secret-Key"];
	
	if(CheckAuthentication($secretid, $secretkey, $server_ip)) {
		$json = file_get_contents('php://input');
		if(trim($json)=="") {
			$return["response_code"]	= 400;			
			$return["message"]			= $AuroLangConvert["400.1"];			
		}
		else {
			$data = json_decode($json,true);
			if(!empty($data)) {
				if (!isset($data["partner_id"]) || $data["partner_id"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.54"];
				}
				elseif (!isset($data["user_name"]) || $data["user_name"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.3"];
				}
				elseif (!isset($data["role_id"]) || $data["role_id"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.52"];
				}
				elseif (!isset($data["user_type_id"]) || $data["user_type_id"] == '' ){
					$return["response_code"]	= 400;	
					$return["message"]			= $AuroLangConvert["400.53"];
				}
				else {
					$user_name 			= filter_var(trim($data["user_name"]), FILTER_SANITIZE_STRING);
					$partner_id			= filter_var(trim($data["partner_id"]), FILTER_SANITIZE_NUMBER_INT);
					$user_type_id 		= filter_var(trim($data["user_type_id"]), FILTER_SANITIZE_NUMBER_INT);
					$password 			= filter_var(trim($data["password"]), FILTER_SANITIZE_STRING);
					$role_id 			= filter_var(trim($data["role_id"]), FILTER_SANITIZE_NUMBER_INT);
					$status 			= filter_var(trim($data["status"]), FILTER_SANITIZE_NUMBER_INT);
					$created_by 		= filter_var(trim($data["created_by"]), FILTER_SANITIZE_NUMBER_INT);
					$updated_by 		= filter_var(trim($data["updated_by"]), FILTER_SANITIZE_NUMBER_INT);
					$created_at 		= date('Y-m-d H:i:s');

					$stmt = $con->prepare("SELECT * FROM auro_partner_master where partner_id=".$partner_id."");
					$stmt->execute();
					$result = $stmt->get_result();
					if($result->num_rows < 1) {
						$return["response_code"]	= 400;	
						$return["message"]			= $AuroLangConvert["400.57"];
					}
					else {
						$row_ptnr = $result->fetch_assoc();
						$new_user_name = strtolower(clean_str($row_ptnr['partner_name'])).'_'.strtolower(clean_str($user_name));
						$stmt = $con->prepare("SELECT * FROM user_master where user_name='".$new_user_name."' and user_type_id='".$user_type_id."'");
						$stmt->execute();
						$result = $stmt->get_result(); 
						if($result->num_rows > 0) {
							$return["response_code"]	= 400;	
							$return["message"]			= $AuroLangConvert["400.25"];
						}
						else {
							$current_date = date('Y-m-d H:i:s');
							if($password == '') $password = $new_user_name;
							$stmt = $con->prepare("INSERT INTO user_master (user_name, password, user_type_id, status, role_id, created_at, created_by,updated_by,updated_at) VALUES ('".$new_user_name."', '".md5($password)."', '".$user_type_id."', '".$status."', '".$role_id."', '".$current_date."', '".$created_by."', '".$updated_by."', '".$current_date."')");
							$stmt->execute();
							$user_id = $stmt->insert_id;

							$stmt = $con->prepare("INSERT INTO partner_user_mapping (partner_id, user_id, created_by, updated_by, created_at, updated_at) VALUES ('".$partner_id."', '".$user_id."', '".$created_by."','".$updated_by."','".$created_at."','".$current_date."')");
							$stmt->execute();
							$partner_user_id = $stmt->insert_id;

							$return["status"]					= "success";
							$return["error"]					= "false";
							$return["response_code"]			= 200;			
							$return["message"]					= $AuroLangConvert["200.1"];
							$return["data"]["user_id"]			= (string)$user_id;
							$return["data"]["partner_id"]		= (string)$partner_id;
							$return["data"]["partner_user_id"]	= (string)$partner_user_id;
						}
					}
					$stmt->close();	
				}
			}
			else {
				$return["response_code"]	= 400;
				$return["message"]			= $AuroLangConvert["400.1"];
			}			
		}
	}
	else {
		$return["response_code"]	= 403;	
		$return["message"]			= $AuroLangConvert["403.1"];
	}
}
else{
	$return["response_code"]	= 403;	
	$return["message"]			= $AuroLangConvert["403.1"];	
}
echo json_encode($return,JSON_UNESCAPED_UNICODE);
?>